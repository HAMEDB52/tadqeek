"""
JSON Schemas للتكامل مع Module 3
Integration Schemas
"""

import json
import hashlib
from datetime import datetime
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


# === Enums ===

class DocumentType(Enum):
    """أنواع المستندات"""
    NATIONAL_ID = "هوية_وطنية"
    PASSPORT = "جواز_سفر"
    DRIVING_LICENSE = "رخصة_قيادة"
    VEHICLE_REG = "استمارة_مركبة"
    BIRTH_CERT = "شهادة_ميلاد"
    FAMILY_CARD = "كرت_عائلة"
    IQAMA = "إقامة"
    MARRIAGE_CONTRACT = "عقد_زواج"
    BANK_STATEMENT = "كشف_حساب"
    PHOTO = "صورة_شخصية"
    OTHER = "أخرى"


class InputType(Enum):
    """أنواع المدخلات"""
    TEXT = "نص"
    VOICE = "صوت"
    IMAGE = "صورة"
    DOCUMENT = "مستند"


class RiskLevel(Enum):
    """مستويات الخطر"""
    LOW = "منخفض"
    MEDIUM = "متوسط"
    HIGH = "مرتفع"
    CRITICAL = "حرج"


# === Data Classes ===

@dataclass
class ExtractedDocument:
    """
    مستند مستخرج - Schema للتكامل مع Module 3
    """
    document_id: str
    document_type: DocumentType
    extracted_text: str
    fields: Dict[str, Any]
    confidence: float
    quality: str  # high, medium, low
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    expiry_date: str = ""
    is_expired: bool = False
    timestamp: str = ""
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        return {
            "document_id": self.document_id,
            "document_type": self.document_type.value,
            "extracted_text": self.extracted_text,
            "fields": self.fields,
            "confidence": self.confidence,
            "quality": self.quality,
            "is_valid": self.is_valid,
            "errors": self.errors,
            "expiry_date": self.expiry_date,
            "is_expired": self.is_expired,
            "timestamp": self.timestamp
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


@dataclass
class UserInput:
    """
    مدخلات المستخدم - Schema للتكامل مع Module 3
    """
    input_id: str
    input_type: InputType
    raw_content: str
    processed_text: str
    intent: str
    service_category: str
    service_name: str
    entities: Dict[str, Any]
    confidence: float
    dialect: str = "standard"
    timestamp: str = ""
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        return {
            "input_id": self.input_id,
            "input_type": self.input_type.value,
            "raw_content": self.raw_content[:100] + "..." if len(self.raw_content) > 100 else self.raw_content,
            "processed_text": self.processed_text,
            "intent": self.intent,
            "service_category": self.service_category,
            "service_name": self.service_name,
            "entities": self.entities,
            "confidence": self.confidence,
            "dialect": self.dialect,
            "timestamp": self.timestamp
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)


@dataclass
class RiskWarning:
    """تحذير خطر"""
    term: str
    level: RiskLevel
    warning: str
    recommendation: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "term": self.term,
            "level": self.level.value,
            "warning": self.warning,
            "recommendation": self.recommendation
        }


@dataclass
class RetrievalResult:
    """نتيجة بحث"""
    chunk_id: str
    content: str
    source: str
    category: str
    score: float
    metadata: Dict = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "chunk_id": self.chunk_id,
            "content": self.content,
            "source": self.source,
            "category": self.category,
            "score": self.score
        }


@dataclass
class IntegrationOutput:
    """
    الخرج الكامل للتكامل مع Module 3
    ====================================
    هذا هو الـ Schema الرئيسي الذي يستقبله Module 3
    """
    request_id: str
    user_input: UserInput
    documents: List[ExtractedDocument]
    retrieved_context: List[RetrievalResult]
    
    # تحليل الطلب
    service_detected: str
    service_category: str
    intent: str
    
    # حالة المتطلبات
    requirements: Dict[str, bool]
    missing_documents: List[str]
    completion_percentage: float
    
    # المخاطر
    risk_warnings: List[RiskWarning]
    risk_level: RiskLevel
    
    # توصيات
    recommendations: List[str]
    
    timestamp: str = ""
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
    
    def to_dict(self) -> Dict:
        return {
            "request_id": self.request_id,
            "timestamp": self.timestamp,
            
            "user_input": self.user_input.to_dict(),
            
            "documents": [d.to_dict() for d in self.documents],
            "documents_count": len(self.documents),
            "valid_documents": sum(1 for d in self.documents if d.is_valid),
            
            "retrieved_context": [r.to_dict() for r in self.retrieved_context[:5]],
            
            "service": {
                "detected": self.service_detected,
                "category": self.service_category,
                "intent": self.intent
            },
            
            "requirements": {
                "status": self.requirements,
                "missing": self.missing_documents,
                "completion": self.completion_percentage
            },
            
            "risk_analysis": {
                "warnings": [w.to_dict() for w in self.risk_warnings],
                "level": self.risk_level.value,
                "warnings_count": len(self.risk_warnings)
            },
            
            "recommendations": self.recommendations,
            
            "ready_for_submission": self.completion_percentage >= 100 and self.risk_level != RiskLevel.CRITICAL
        }
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    
    def summary(self) -> str:
        """ملخص سريع"""
        return f"""
📋 طلب: {self.request_id}
🎯 الخدمة: {self.service_detected} ({self.service_category})
📄 المستندات: {len(self.documents)} ({sum(1 for d in self.documents if d.is_valid)} صالح)
✅ الاكتمال: {self.completion_percentage:.0f}%
⚠️ التحذيرات: {len(self.risk_warnings)}
🚦 مستوى الخطر: {self.risk_level.value}
"""


# === Helper Functions ===

def generate_id(prefix: str = "REQ") -> str:
    """توليد ID فريد"""
    ts = datetime.now().strftime("%Y%m%d%H%M%S")
    rand = hashlib.md5(f"{ts}".encode()).hexdigest()[:6]
    return f"{prefix}-{ts}-{rand}"


def create_sample_output() -> IntegrationOutput:
    """مثال على الخرج"""
    return IntegrationOutput(
        request_id=generate_id(),
        user_input=UserInput(
            input_id=generate_id("INP"),
            input_type=InputType.VOICE,
            raw_content="audio_data...",
            processed_text="أبغى أجدد جواز السفر",
            intent="تجديد",
            service_category="الجوازات",
            service_name="تجديد جواز السفر",
            entities={"service": "جواز_سفر"},
            confidence=0.95,
            dialect="najdi"
        ),
        documents=[
            ExtractedDocument(
                document_id=generate_id("DOC"),
                document_type=DocumentType.NATIONAL_ID,
                extracted_text="...",
                fields={"id_number": "1234567890", "name_ar": "محمد أحمد"},
                confidence=0.92,
                quality="high",
                is_valid=True,
                expiry_date="2027-05-15",
                is_expired=False
            )
        ],
        retrieved_context=[
            RetrievalResult(
                chunk_id="chunk_1",
                content="تجديد جواز السفر يتطلب...",
                source="absher",
                category="الجوازات",
                score=0.89
            )
        ],
        service_detected="تجديد جواز السفر",
        service_category="الجوازات",
        intent="تجديد",
        requirements={"هوية_وطنية": True, "صورة_شخصية": False},
        missing_documents=["صورة_شخصية"],
        completion_percentage=50.0,
        risk_warnings=[],
        risk_level=RiskLevel.LOW,
        recommendations=["يرجى رفع صورة شخصية حديثة"]
    )


if __name__ == "__main__":
    print("=" * 50)
    print("📋 Integration Schemas")
    print("=" * 50)
    
    sample = create_sample_output()
    print("\n📄 Sample Output:")
    print(sample.summary())
    print("\n📝 JSON:")
    print(sample.to_json()[:500] + "...")
