"""
OCR System - استخراج النصوص من المستندات
Uses Ollama Vision (llama3.2-vision / llava)
"""

import json
import re
import hashlib
from datetime import datetime
from typing import Dict, Optional, List

from ollama_client import OllamaClient
from schemas import DocumentType, ExtractedDocument


class OCRSystem:
    """نظام OCR للمستندات السعودية"""
    
    # قوالب الاستخراج لكل نوع مستند
    PROMPTS = {
        DocumentType.NATIONAL_ID: """
استخرج بيانات الهوية الوطنية السعودية من الصورة.
أعد JSON فقط بالصيغة التالية (بدون أي نص إضافي):
{
    "id_number": "رقم الهوية (10 أرقام)",
    "name_ar": "الاسم بالعربي",
    "name_en": "الاسم بالإنجليزي",
    "birth_date": "تاريخ الميلاد",
    "expiry_date": "تاريخ الانتهاء",
    "gender": "ذكر/أنثى"
}
اكتب "غير_واضح" للحقول غير المقروءة.
""",
        DocumentType.PASSPORT: """
استخرج بيانات جواز السفر السعودي:
{
    "passport_number": "رقم الجواز",
    "name_ar": "الاسم بالعربي",
    "name_en": "الاسم بالإنجليزي",
    "birth_date": "تاريخ الميلاد",
    "issue_date": "تاريخ الإصدار",
    "expiry_date": "تاريخ الانتهاء"
}
أعد JSON فقط.
""",
        DocumentType.DRIVING_LICENSE: """
استخرج بيانات رخصة القيادة:
{
    "license_number": "رقم الرخصة",
    "name_ar": "الاسم",
    "id_number": "رقم الهوية",
    "license_type": "نوع الرخصة",
    "expiry_date": "تاريخ الانتهاء"
}
أعد JSON فقط.
""",
        DocumentType.VEHICLE_REG: """
استخرج بيانات استمارة المركبة:
{
    "plate_number": "رقم اللوحة",
    "owner_name": "اسم المالك",
    "vehicle_make": "الشركة",
    "model": "الموديل",
    "year": "السنة",
    "expiry_date": "تاريخ الانتهاء"
}
أعد JSON فقط.
""",
        DocumentType.IQAMA: """
استخرج بيانات الإقامة:
{
    "iqama_number": "رقم الإقامة",
    "name_ar": "الاسم بالعربي",
    "name_en": "الاسم بالإنجليزي",
    "nationality": "الجنسية",
    "profession": "المهنة",
    "sponsor": "الكفيل",
    "expiry_date": "تاريخ الانتهاء"
}
أعد JSON فقط.
""",
        DocumentType.BANK_STATEMENT: """
استخرج بيانات كشف الحساب:
{
    "bank_name": "اسم البنك",
    "account_holder": "صاحب الحساب",
    "account_number": "رقم الحساب",
    "balance": "الرصيد",
    "statement_date": "تاريخ الكشف"
}
أعد JSON فقط.
"""
    }
    
    # أنماط التحقق
    PATTERNS = {
        DocumentType.NATIONAL_ID: {"id_number": r"^[12]\d{9}$"},
        DocumentType.PASSPORT: {"passport_number": r"^[A-Z]\d{8}$"},
        DocumentType.DRIVING_LICENSE: {"license_number": r"^\d{10}$"},
        DocumentType.IQAMA: {"iqama_number": r"^2\d{9}$"}
    }
    
    # الحقول المطلوبة
    REQUIRED_FIELDS = {
        DocumentType.NATIONAL_ID: ["id_number", "name_ar"],
        DocumentType.PASSPORT: ["passport_number", "name_ar"],
        DocumentType.DRIVING_LICENSE: ["license_number", "name_ar"],
        DocumentType.VEHICLE_REG: ["plate_number", "owner_name"],
        DocumentType.IQAMA: ["iqama_number", "name_ar"],
        DocumentType.BANK_STATEMENT: ["account_number", "balance"]
    }
    
    def __init__(self, ollama: OllamaClient):
        self.ollama = ollama
    
    def detect_type(self, image_b64: str) -> DocumentType:
        """كشف نوع المستند تلقائياً"""
        prompt = """
حدد نوع المستند السعودي في الصورة.
أجب بكلمة واحدة فقط من القائمة:
هوية_وطنية, جواز_سفر, رخصة_قيادة, استمارة_مركبة, إقامة, كشف_حساب, شهادة_ميلاد, أخرى
"""
        result = self.ollama.vision(image_b64, prompt).strip()
        
        mapping = {
            "هوية_وطنية": DocumentType.NATIONAL_ID,
            "جواز_سفر": DocumentType.PASSPORT,
            "رخصة_قيادة": DocumentType.DRIVING_LICENSE,
            "استمارة_مركبة": DocumentType.VEHICLE_REG,
            "إقامة": DocumentType.IQAMA,
            "كشف_حساب": DocumentType.BANK_STATEMENT,
            "شهادة_ميلاد": DocumentType.BIRTH_CERT
        }
        
        return mapping.get(result, DocumentType.OTHER)
    
    def extract(self, image_b64: str, doc_type: DocumentType = None) -> ExtractedDocument:
        """استخراج بيانات المستند"""
        
        # كشف النوع إذا لم يُحدد
        if doc_type is None:
            doc_type = self.detect_type(image_b64)
        
        # الاستخراج
        prompt = self.PROMPTS.get(doc_type, "استخرج كل النصوص من الصورة كـ JSON")
        raw_result = self.ollama.vision(image_b64, prompt)
        
        # تحويل لـ JSON
        fields = self._parse_json(raw_result)
        
        # التحقق والتقييم
        errors = self._validate(fields, doc_type)
        quality = self._assess_quality(fields, doc_type)
        confidence = self._calculate_confidence(fields, doc_type)
        
        # التحقق من الصلاحية
        expiry = fields.get("expiry_date", "")
        is_expired = self._check_expiry(expiry)
        
        return ExtractedDocument(
            document_id=hashlib.md5(image_b64[:100].encode()).hexdigest()[:12],
            document_type=doc_type,
            extracted_text=raw_result,
            fields=fields,
            confidence=confidence,
            quality=quality,
            is_valid=len(errors) == 0 and not is_expired,
            errors=errors,
            expiry_date=expiry,
            is_expired=is_expired
        )
    
    def _parse_json(self, text: str) -> Dict:
        """استخراج JSON من النص"""
        try:
            # البحث عن JSON
            match = re.search(r'\{[^{}]+\}', text, re.DOTALL)
            if match:
                return json.loads(match.group())
        except json.JSONDecodeError:
            pass
        return {}
    
    def _validate(self, fields: Dict, doc_type: DocumentType) -> List[str]:
        """التحقق من صحة الحقول"""
        errors = []
        
        # التحقق من الحقول المطلوبة
        required = self.REQUIRED_FIELDS.get(doc_type, [])
        for field in required:
            if not fields.get(field) or fields.get(field) == "غير_واضح":
                errors.append(f"حقل {field} مطلوب")
        
        # التحقق من الأنماط
        patterns = self.PATTERNS.get(doc_type, {})
        for field_name, pattern in patterns.items():
            value = fields.get(field_name, "")
            if value and value != "غير_واضح":
                if not re.match(pattern, str(value)):
                    errors.append(f"صيغة {field_name} غير صحيحة")
        
        return errors
    
    def _assess_quality(self, fields: Dict, doc_type: DocumentType) -> str:
        """تقييم جودة الاستخراج"""
        if not fields:
            return "low"
        
        required = self.REQUIRED_FIELDS.get(doc_type, ["name_ar"])
        found = sum(1 for f in required if fields.get(f) and fields[f] != "غير_واضح")
        
        if found == len(required):
            return "high"
        elif found > 0:
            return "medium"
        return "low"
    
    def _calculate_confidence(self, fields: Dict, doc_type: DocumentType) -> float:
        """حساب نسبة الثقة"""
        if not fields:
            return 0.0
        
        total = len(fields)
        valid = sum(1 for v in fields.values() if v and v != "غير_واضح")
        base = valid / total if total > 0 else 0
        
        # إضافة نقاط للأنماط الصحيحة
        patterns = self.PATTERNS.get(doc_type, {})
        if patterns:
            matches = sum(
                1 for f, p in patterns.items()
                if fields.get(f) and re.match(p, str(fields.get(f, "")))
            )
            pattern_score = matches / len(patterns)
            return round((base + pattern_score) / 2, 2)
        
        return round(base, 2)
    
    def _check_expiry(self, expiry_date: str) -> bool:
        """التحقق من انتهاء الصلاحية"""
        if not expiry_date or expiry_date == "غير_واضح":
            return False
        
        try:
            # محاولة تحليل التاريخ
            for fmt in ["%Y/%m/%d", "%Y-%m-%d", "%d/%m/%Y"]:
                try:
                    exp = datetime.strptime(expiry_date, fmt)
                    return exp < datetime.now()
                except ValueError:
                    continue
        except:
            pass
        
        return False
    
    def extract_batch(self, images: List[tuple]) -> List[ExtractedDocument]:
        """استخراج من عدة صور"""
        results = []
        for img_b64, doc_type in images:
            results.append(self.extract(img_b64, doc_type))
        return results


# === Mock OCR للاختبار ===

class MockOCR:
    """OCR وهمي للاختبار بدون Ollama"""
    
    MOCK_DATA = {
        DocumentType.NATIONAL_ID: {
            "id_number": "1234567890",
            "name_ar": "محمد أحمد العلي",
            "name_en": "MOHAMMED AHMED ALALI",
            "birth_date": "1990/05/15",
            "expiry_date": "2027/05/15",
            "gender": "ذكر"
        },
        DocumentType.PASSPORT: {
            "passport_number": "A12345678",
            "name_ar": "محمد أحمد العلي",
            "name_en": "MOHAMMED AHMED ALALI",
            "birth_date": "1990/05/15",
            "issue_date": "2022/01/01",
            "expiry_date": "2027/01/01"
        },
        DocumentType.DRIVING_LICENSE: {
            "license_number": "1234567890",
            "name_ar": "محمد أحمد العلي",
            "id_number": "1234567890",
            "license_type": "خاصة",
            "expiry_date": "2026/03/15"
        }
    }
    
    def extract(self, image_b64: str, doc_type: DocumentType = None) -> ExtractedDocument:
        doc_type = doc_type or DocumentType.NATIONAL_ID
        fields = self.MOCK_DATA.get(doc_type, {"name_ar": "غير معروف"})
        
        return ExtractedDocument(
            document_id=hashlib.md5(image_b64[:50].encode()).hexdigest()[:12],
            document_type=doc_type,
            extracted_text="mock_extraction",
            fields=fields,
            confidence=0.95,
            quality="high",
            is_valid=True,
            expiry_date=fields.get("expiry_date", ""),
            is_expired=False
        )


if __name__ == "__main__":
    print("=" * 50)
    print("📷 OCR System Test")
    print("=" * 50)
    
    # اختبار Mock
    mock_ocr = MockOCR()
    result = mock_ocr.extract("fake_image_data", DocumentType.NATIONAL_ID)
    
    print(f"\n📄 Mock Extraction:")
    print(f"   Type: {result.document_type.value}")
    print(f"   Fields: {result.fields}")
    print(f"   Valid: {result.is_valid}")
    print(f"   Confidence: {result.confidence}")
    
    print(f"\n📝 JSON Output:")
    print(result.to_json()[:300] + "...")
