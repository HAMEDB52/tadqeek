"""
مستشار الوكالات الذكي
Wakala (Power of Attorney) Advisor

يحلل نصوص الوكالات ويحذر من الصلاحيات الخطرة
"""

import re
from typing import List, Dict
from dataclasses import dataclass

from schemas import RiskLevel, RiskWarning


@dataclass
class WakalaAnalysis:
    """تحليل الوكالة"""
    wakala_type: str
    risk_level: RiskLevel
    warnings: List[RiskWarning]
    safe_alternative: str
    recommendations: List[str]
    
    def to_dict(self) -> Dict:
        return {
            "wakala_type": self.wakala_type,
            "risk_level": self.risk_level.value,
            "warnings": [w.to_dict() for w in self.warnings],
            "warnings_count": len(self.warnings),
            "safe_alternative": self.safe_alternative,
            "recommendations": self.recommendations
        }


class WakalaAdvisor:
    """مستشار الوكالات"""
    
    # أنواع الوكالات
    WAKALA_TYPES = {
        "عامة": {
            "risk": RiskLevel.CRITICAL,
            "description": "وكالة شاملة لجميع التصرفات",
            "warning": "تمنح صلاحيات واسعة جداً قد تشمل البيع والشراء والتنازل عن كل حقوقك",
            "recommendation": "لا يُنصح بها إطلاقاً إلا للضرورة القصوى ولشخص موثوق جداً"
        },
        "خاصة": {
            "risk": RiskLevel.LOW,
            "description": "وكالة محددة لتصرف معين",
            "warning": "محدودة بالغرض المحدد فقط",
            "recommendation": "الخيار الأفضل والأكثر أماناً - حدد الغرض بدقة"
        },
        "بيع عقار": {
            "risk": RiskLevel.MEDIUM,
            "description": "وكالة لبيع عقار محدد",
            "warning": "تأكد من تحديد العقار بدقة (رقم الصك، الموقع)",
            "recommendation": "حدد العقار ومبلغ البيع الأدنى ومدة الوكالة"
        },
        "استلام": {
            "risk": RiskLevel.LOW,
            "description": "وكالة لاستلام مستندات أو أموال محددة",
            "warning": "آمنة نسبياً لكن حدد ما يمكن استلامه بالضبط",
            "recommendation": "حدد المستند/المبلغ بالتفصيل"
        },
        "قضائية": {
            "risk": RiskLevel.MEDIUM,
            "description": "وكالة للتمثيل أمام المحاكم",
            "warning": "تأكد من تحديد القضية والمحكمة",
            "recommendation": "حدد رقم القضية ونوع التصرفات المسموحة (الحضور فقط أم الصلح أيضاً)"
        }
    }
    
    # العبارات الخطرة
    DANGEROUS_TERMS = [
        {
            "pattern": r"التنازل\s*(عن)?\s*كافة\s*الحقوق",
            "term": "التنازل عن كافة الحقوق",
            "risk": RiskLevel.CRITICAL,
            "warning": "تسمح للوكيل بالتنازل عن أي حق من حقوقك",
            "recommendation": "احذف هذه العبارة تماماً أو حدد الحقوق المحددة"
        },
        {
            "pattern": r"بدون\s*(أي)?\s*قيود",
            "term": "بدون قيود",
            "risk": RiskLevel.CRITICAL,
            "warning": "تزيل كل الحماية القانونية وتمنح صلاحيات مفتوحة",
            "recommendation": "أضف قيوداً واضحة ومحددة"
        },
        {
            "pattern": r"تفويض\s*مطلق",
            "term": "تفويض مطلق",
            "risk": RiskLevel.CRITICAL,
            "warning": "صلاحيات غير محدودة - خطر جداً",
            "recommendation": "استبدل بـ 'تفويض محدد لـ [الغرض]'"
        },
        {
            "pattern": r"لأي\s*وقت\s*(مستقبلي)?",
            "term": "لأي وقت مستقبلي",
            "risk": RiskLevel.HIGH,
            "warning": "وكالة مفتوحة بلا نهاية - قد تُستخدم بعد سنوات",
            "recommendation": "حدد مدة الوكالة (مثلاً: سنة واحدة)"
        },
        {
            "pattern": r"كافة\s*التصرفات",
            "term": "كافة التصرفات",
            "risk": RiskLevel.HIGH,
            "warning": "تشمل البيع والرهن والهبة والتنازل",
            "recommendation": "حدد التصرفات المسموحة فقط"
        },
        {
            "pattern": r"نيابة\s*كاملة",
            "term": "نيابة كاملة",
            "risk": RiskLevel.HIGH,
            "warning": "تمثيل كامل في كل شيء كأنك أنت",
            "recommendation": "حدد نطاق النيابة"
        },
        {
            "pattern": r"البيع\s*(و|أو)\s*الشراء\s*(و|أو)\s*الرهن",
            "term": "البيع والشراء والرهن",
            "risk": RiskLevel.HIGH,
            "warning": "صلاحيات مالية واسعة",
            "recommendation": "حدد فقط ما تحتاجه"
        },
        {
            "pattern": r"التوقيع\s*على\s*أي\s*عقد",
            "term": "التوقيع على أي عقد",
            "risk": RiskLevel.CRITICAL,
            "warning": "يمكن للوكيل توقيع أي التزام باسمك",
            "recommendation": "حدد نوع العقود المسموحة"
        },
        {
            "pattern": r"سحب\s*(أي)?\s*مبالغ",
            "term": "سحب أي مبالغ",
            "risk": RiskLevel.CRITICAL,
            "warning": "الوصول لجميع أموالك",
            "recommendation": "حدد المبلغ الأقصى والغرض"
        },
        {
            "pattern": r"إقرار\s*(نهائي)?\s*لا\s*رجعة",
            "term": "إقرار لا رجعة فيه",
            "risk": RiskLevel.HIGH,
            "warning": "لا يمكنك التراجع عن أي قرار",
            "recommendation": "احذف هذه العبارة"
        }
    ]
    
    # البدائل الآمنة
    SAFE_ALTERNATIVES = {
        "عامة": "وكالة خاصة محددة الغرض والمدة",
        "بيع": "وكالة بيع عقار محدد برقم الصك ومبلغ أدنى ومدة محددة",
        "مالية": "وكالة استلام مبلغ محدد من جهة محددة",
        "قضائية": "وكالة حضور جلسات قضية محددة بدون صلاحية الصلح"
    }
    
    def analyze(self, wakala_text: str) -> WakalaAnalysis:
        """تحليل نص الوكالة"""
        warnings = []
        max_risk = RiskLevel.LOW
        wakala_type = "خاصة"
        
        # كشف نوع الوكالة
        if "عامة" in wakala_text or "وكالة عامة" in wakala_text:
            wakala_type = "عامة"
            max_risk = RiskLevel.CRITICAL
            warnings.append(RiskWarning(
                term="وكالة عامة",
                level=RiskLevel.CRITICAL,
                warning="الوكالة العامة خطيرة جداً - تمنح صلاحيات شاملة",
                recommendation="استبدل بوكالة خاصة محددة الغرض"
            ))
        
        # البحث عن العبارات الخطرة
        for item in self.DANGEROUS_TERMS:
            if re.search(item["pattern"], wakala_text, re.IGNORECASE):
                risk = item["risk"]
                warnings.append(RiskWarning(
                    term=item["term"],
                    level=risk,
                    warning=item["warning"],
                    recommendation=item["recommendation"]
                ))
                
                # تحديث أعلى مستوى خطر
                risk_order = [RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
                if risk_order.index(risk) > risk_order.index(max_risk):
                    max_risk = risk
        
        # تحديد البديل الآمن
        if wakala_type == "عامة":
            safe_alt = self.SAFE_ALTERNATIVES["عامة"]
        elif "بيع" in wakala_text or "عقار" in wakala_text:
            safe_alt = self.SAFE_ALTERNATIVES["بيع"]
        elif "مال" in wakala_text or "سحب" in wakala_text or "حساب" in wakala_text:
            safe_alt = self.SAFE_ALTERNATIVES["مالية"]
        elif "قضية" in wakala_text or "محكمة" in wakala_text:
            safe_alt = self.SAFE_ALTERNATIVES["قضائية"]
        else:
            safe_alt = "وكالة خاصة محددة الغرض والمدة (سنة واحدة كحد أقصى)"
        
        # التوصيات
        recommendations = []
        if max_risk == RiskLevel.CRITICAL:
            recommendations.append("⛔ لا توقع على هذه الوكالة!")
            recommendations.append("راجع محامي قبل التوقيع")
        elif max_risk == RiskLevel.HIGH:
            recommendations.append("⚠️ احذر - راجع البنود بعناية")
            recommendations.append("احذف العبارات الخطرة المذكورة")
        
        if warnings:
            recommendations.append("اطلب تعديل الوكالة قبل التوقيع")
        
        recommendations.append("حدد مدة الوكالة (لا تتجاوز سنة)")
        recommendations.append("احتفظ بنسخة من الوكالة")
        
        return WakalaAnalysis(
            wakala_type=wakala_type,
            risk_level=max_risk,
            warnings=warnings,
            safe_alternative=safe_alt,
            recommendations=recommendations
        )
    
    def explain_type(self, wakala_type: str) -> Dict:
        """شرح نوع وكالة"""
        info = self.WAKALA_TYPES.get(wakala_type, self.WAKALA_TYPES["خاصة"])
        return {
            "type": wakala_type,
            "risk": info["risk"].value,
            "description": info["description"],
            "warning": info["warning"],
            "recommendation": info["recommendation"]
        }
    
    def suggest_safe_wakala(self, purpose: str) -> str:
        """اقتراح وكالة آمنة"""
        templates = {
            "بيع عقار": """
وكالة خاصة لبيع عقار
أوكل السيد/ة [اسم الوكيل] هوية رقم [رقم] ببيع العقار المملوك لي:
- رقم الصك: [رقم الصك]
- الموقع: [العنوان]
- المساحة: [المساحة]
بمبلغ لا يقل عن [المبلغ] ريال
مدة الوكالة: [المدة] من تاريخه
لا تشمل هذه الوكالة أي تصرف آخر غير البيع
""",
            "استلام مستندات": """
وكالة خاصة لاستلام مستندات
أوكل السيد/ة [اسم الوكيل] باستلام:
- [نوع المستند]
من جهة: [اسم الجهة]
مدة الوكالة: شهر واحد من تاريخه
""",
            "تجديد جواز": """
وكالة خاصة لتجديد جواز سفر
أوكل السيد/ة [اسم الوكيل] بتجديد جواز سفري رقم [رقم الجواز]
واستلام الجواز الجديد نيابة عني
مدة الوكالة: شهرين من تاريخه
"""
        }
        
        # البحث عن قالب مناسب
        for key, template in templates.items():
            if key in purpose or any(w in purpose for w in key.split()):
                return template
        
        # قالب افتراضي
        return f"""
وكالة خاصة لـ {purpose}
أوكل السيد/ة [اسم الوكيل] هوية رقم [رقم] بـ:
- [تحديد الصلاحية بدقة]
مدة الوكالة: [المدة] من تاريخه
لا تشمل هذه الوكالة أي تصرف آخر غير المذكور أعلاه
"""


# === Tests ===

def test_wakala_advisor():
    """اختبار مستشار الوكالات"""
    advisor = WakalaAdvisor()
    
    # وكالة خطرة
    dangerous = """
    وكالة عامة
    أوكل فلان بن فلان بالتصرف في جميع أموالي وممتلكاتي
    بدون أي قيود مع التنازل عن كافة الحقوق
    وله التوقيع على أي عقد والسحب من حساباتي
    لأي وقت مستقبلي
    """
    
    result = advisor.analyze(dangerous)
    
    print("\n⚠️ Dangerous Wakala Analysis:")
    print(f"   Type: {result.wakala_type}")
    print(f"   Risk: {result.risk_level.value}")
    print(f"   Warnings: {len(result.warnings)}")
    for w in result.warnings:
        print(f"      🔴 {w.term}: {w.warning}")
    print(f"   Safe Alternative: {result.safe_alternative}")
    
    # وكالة آمنة
    safe = """
    وكالة خاصة لاستلام جواز السفر
    أوكل محمد أحمد باستلام جواز سفري من مكتب الجوازات
    مدة الوكالة شهر واحد
    """
    
    result2 = advisor.analyze(safe)
    
    print("\n✅ Safe Wakala Analysis:")
    print(f"   Type: {result2.wakala_type}")
    print(f"   Risk: {result2.risk_level.value}")
    print(f"   Warnings: {len(result2.warnings)}")
    
    return result.risk_level == RiskLevel.CRITICAL and result2.risk_level == RiskLevel.LOW


if __name__ == "__main__":
    print("=" * 50)
    print("📜 Wakala Advisor Test")
    print("=" * 50)
    
    test_wakala_advisor()
    
    # اقتراح وكالة آمنة
    advisor = WakalaAdvisor()
    print("\n📝 Safe Wakala Suggestion:")
    print(advisor.suggest_safe_wakala("بيع عقار"))
