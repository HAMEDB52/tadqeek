"""
اختبارات شاملة لنظام RAG
Comprehensive Tests
"""

import json
from datetime import datetime

from ollama_client import OllamaClient, OllamaConfig, check_gpu, recommended_models
from knowledge_base import get_all_services, get_indexable_content, FAQ
from schemas import DocumentType, InputType, RiskLevel, create_sample_output
from vector_db import VectorDB, DataIngestion
from ocr_system import MockOCR
from speech_to_text import SpeechToText
from wakala_advisor import WakalaAdvisor
from rag_system import RAGSystem, create_rag_system


def test_ollama_client():
    """اختبار Ollama Client"""
    print("\n" + "=" * 60)
    print("🖥️ Test 1: Ollama Client")
    print("=" * 60)
    
    print(f"\n📊 GPU Info: {check_gpu()}")
    print(f"📋 Recommended Models: {recommended_models(16)}")
    
    client = OllamaClient()
    available = client.is_available()
    
    print(f"\n🔌 Ollama Status: {'✓ Connected' if available else '✗ Not Running'}")
    
    if available:
        models = client.list_models()
        print(f"   Models: {models[:5]}")
        
        # اختبار embedding
        emb = client.embed("اختبار")
        print(f"   Embedding dim: {len(emb)}")
    
    return True


def test_knowledge_base():
    """اختبار قاعدة المعرفة"""
    print("\n" + "=" * 60)
    print("📚 Test 2: Knowledge Base")
    print("=" * 60)
    
    services = get_all_services()
    content = get_indexable_content()
    
    print(f"\n   Services: {len(services)}")
    print(f"   FAQ: {len(FAQ)}")
    print(f"   Indexable items: {len(content)}")
    
    # عرض الفئات
    categories = {}
    for s in services.values():
        cat = s["category"]
        categories[cat] = categories.get(cat, 0) + 1
    
    print("\n   Categories:")
    for cat, count in categories.items():
        print(f"      - {cat}: {count}")
    
    return len(services) > 0


def test_data_ingestion():
    """اختبار تجهيز البيانات"""
    print("\n" + "=" * 60)
    print("📝 Test 3: Data Ingestion")
    print("=" * 60)
    
    ingestion = DataIngestion(chunk_size=300, overlap=50)
    
    # تنظيف
    dirty = "  هذا   نص    فيه   مسافات   زائدة   "
    clean = ingestion.clean(dirty)
    print(f"\n   Clean: '{dirty}' → '{clean}'")
    
    # تقسيم
    text = "هذه جملة أولى. هذه جملة ثانية، وهذه ثالثة. وهذه جملة طويلة جداً تحتوي على كلام كثير."
    chunks = ingestion.chunk(text)
    print(f"   Chunks: {len(chunks)}")
    
    return len(chunks) > 0


def test_speech_to_text():
    """اختبار تحويل الصوت"""
    print("\n" + "=" * 60)
    print("🎤 Test 4: Speech-to-Text")
    print("=" * 60)
    
    stt = SpeechToText()
    
    # اختبار اللهجات
    dialect_tests = [
        ("وش تبي اللحين؟", "najdi"),
        ("إيش عايز دحين؟", "hijazi"),
        ("شلون هيج؟", "eastern"),
        ("ماذا تريد؟", "standard")
    ]
    
    print("\n   Dialect Detection:")
    correct = 0
    for text, expected in dialect_tests:
        detected = stt.detect_dialect(text)
        ok = detected == expected
        correct += 1 if ok else 0
        print(f"      '{text}' → {detected} {'✓' if ok else '✗'}")
    
    print(f"      Accuracy: {correct}/{len(dialect_tests)}")
    
    # اختبار النوايا
    intent_tests = [
        ("أبغى أجدد الجواز", "تجديد"),
        ("كيف أطلع رخصة؟", "إصدار"),
        ("وش الشروط؟", "استعلام")
    ]
    
    print("\n   Intent Detection:")
    for text, expected in intent_tests:
        detected = stt.detect_intent(text)
        print(f"      '{text}' → {detected} {'✓' if detected == expected else '✗'}")
    
    # معالجة كاملة
    result = stt.process_text("أبغى أجدد جواز السفر")
    print(f"\n   Full Processing:")
    print(f"      Service: {result.service_name}")
    print(f"      Category: {result.service_category}")
    print(f"      Intent: {result.intent}")
    
    return correct >= len(dialect_tests) - 1


def test_ocr():
    """اختبار OCR"""
    print("\n" + "=" * 60)
    print("📷 Test 5: OCR System")
    print("=" * 60)
    
    ocr = MockOCR()
    
    result = ocr.extract("fake_image", DocumentType.NATIONAL_ID)
    
    print(f"\n   Document Type: {result.document_type.value}")
    print(f"   Fields: {list(result.fields.keys())}")
    print(f"   Confidence: {result.confidence}")
    print(f"   Valid: {result.is_valid}")
    
    return result.is_valid


def test_wakala_advisor():
    """اختبار مستشار الوكالات"""
    print("\n" + "=" * 60)
    print("📜 Test 6: Wakala Advisor")
    print("=" * 60)
    
    advisor = WakalaAdvisor()
    
    # وكالة خطرة
    dangerous = "وكالة عامة بدون قيود مع التنازل عن كافة الحقوق وتفويض مطلق"
    result1 = advisor.analyze(dangerous)
    
    print(f"\n   Dangerous Wakala:")
    print(f"      Risk: {result1.risk_level.value}")
    print(f"      Warnings: {len(result1.warnings)}")
    
    # وكالة آمنة
    safe = "وكالة خاصة لاستلام جواز السفر من الجوازات"
    result2 = advisor.analyze(safe)
    
    print(f"\n   Safe Wakala:")
    print(f"      Risk: {result2.risk_level.value}")
    print(f"      Warnings: {len(result2.warnings)}")
    
    return result1.risk_level == RiskLevel.CRITICAL


def test_schemas():
    """اختبار Schemas"""
    print("\n" + "=" * 60)
    print("📋 Test 7: Integration Schemas")
    print("=" * 60)
    
    sample = create_sample_output()
    
    print(f"\n   Request ID: {sample.request_id}")
    print(f"   Service: {sample.service_detected}")
    print(f"   Completion: {sample.completion_percentage}%")
    print(f"   Ready: {sample.to_dict()['ready_for_submission']}")
    
    # JSON output
    json_out = sample.to_json()
    print(f"\n   JSON length: {len(json_out)} chars")
    
    return True


def test_full_pipeline():
    """اختبار خط المعالجة الكامل"""
    print("\n" + "=" * 60)
    print("🔄 Test 8: Full Pipeline")
    print("=" * 60)
    
    # إنشاء النظام (mock mode)
    rag = create_rag_system(use_mock=True)
    
    print(f"\n   System initialized: {rag.initialized}")
    print(f"   Mock mode: {rag.use_mock}")
    
    # معالجة طلب
    result = rag.process_request(text="أبغى أجدد جواز السفر")
    
    print(f"\n   Request: {result.request_id}")
    print(f"   Service: {result.service_detected}")
    print(f"   Category: {result.service_category}")
    print(f"   Intent: {result.intent}")
    print(f"   Completion: {result.completion_percentage}%")
    print(f"   Risk: {result.risk_level.value}")
    
    return result.request_id is not None


def run_all_tests():
    """تشغيل كل الاختبارات"""
    print("\n" + "=" * 70)
    print("🧪 RAG INFRASTRUCTURE - COMPREHENSIVE TEST SUITE")
    print("=" * 70)
    
    tests = [
        ("Ollama Client", test_ollama_client),
        ("Knowledge Base", test_knowledge_base),
        ("Data Ingestion", test_data_ingestion),
        ("Speech-to-Text", test_speech_to_text),
        ("OCR System", test_ocr),
        ("Wakala Advisor", test_wakala_advisor),
        ("Integration Schemas", test_schemas),
        ("Full Pipeline", test_full_pipeline)
    ]
    
    results = {}
    
    for name, func in tests:
        try:
            passed = func()
            results[name] = "✓ PASS" if passed else "✗ FAIL"
        except Exception as e:
            results[name] = f"✗ ERROR: {str(e)[:30]}"
    
    # ملخص
    print("\n" + "=" * 70)
    print("📊 TEST RESULTS")
    print("=" * 70)
    
    for name, result in results.items():
        print(f"   {name}: {result}")
    
    passed = sum(1 for r in results.values() if "PASS" in r)
    total = len(results)
    
    print(f"\n   Overall: {passed}/{total} ({passed/total*100:.0f}%)")
    print("=" * 70)
    
    return results


if __name__ == "__main__":
    run_all_tests()
