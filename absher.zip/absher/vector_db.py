"""
Vector Database - قاعدة البيانات المتجهة
Uses Ollama nomic-embed-text for embeddings
"""

import json
import hashlib
from typing import List, Dict, Optional
from dataclasses import dataclass, field

from ollama_client import OllamaClient
from schemas import RetrievalResult


@dataclass
class Document:
    """مستند في القاعدة"""
    id: str
    content: str
    category: str
    title: str = ""
    metadata: Dict = field(default_factory=dict)


class VectorDB:
    """قاعدة بيانات متجهة بسيطة"""
    
    def __init__(self, ollama: OllamaClient):
        self.ollama = ollama
        self.docs: List[Document] = []
        self.embeddings: List[List[float]] = []
        self._chromadb = None
        self._collection = None
        
        # محاولة استخدام ChromaDB
        self._init_chromadb()
    
    def _init_chromadb(self):
        """تهيئة ChromaDB"""
        try:
            import chromadb
            self._chromadb = chromadb.Client()
            self._collection = self._chromadb.create_collection(
                name="absher_kb",
                metadata={"hnsw:space": "cosine"}
            )
            print("✓ ChromaDB initialized")
        except ImportError:
            print("⚠ ChromaDB not installed, using in-memory")
        except Exception as e:
            print(f"⚠ ChromaDB error: {e}, using in-memory")
    
    @property
    def use_chroma(self) -> bool:
        return self._collection is not None
    
    def add(self, content: str, category: str, title: str = "", metadata: Dict = None) -> str:
        """إضافة مستند"""
        doc_id = hashlib.md5(content.encode()).hexdigest()[:12]
        
        # الحصول على embedding
        embedding = self.ollama.embed(content)
        if not embedding:
            print(f"⚠ Failed to embed: {title[:30]}...")
            return ""
        
        if self.use_chroma:
            self._collection.add(
                ids=[doc_id],
                embeddings=[embedding],
                documents=[content],
                metadatas=[{"category": category, "title": title, **(metadata or {})}]
            )
        else:
            self.docs.append(Document(
                id=doc_id,
                content=content,
                category=category,
                title=title,
                metadata=metadata or {}
            ))
            self.embeddings.append(embedding)
        
        return doc_id
    
    def add_batch(self, items: List[Dict]) -> int:
        """إضافة مستندات متعددة"""
        count = 0
        for item in items:
            if self.add(
                content=item.get("content", ""),
                category=item.get("category", ""),
                title=item.get("title", ""),
                metadata=item.get("metadata", {})
            ):
                count += 1
        return count
    
    def _cosine(self, a: List[float], b: List[float]) -> float:
        """Cosine similarity"""
        if not a or not b or len(a) != len(b):
            return 0.0
        
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x ** 2 for x in a) ** 0.5
        norm_b = sum(x ** 2 for x in b) ** 0.5
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        return dot / (norm_a * norm_b)
    
    def search(self, query: str, k: int = 5, threshold: float = 0.5) -> List[RetrievalResult]:
        """البحث في القاعدة"""
        query_emb = self.ollama.embed(query)
        if not query_emb:
            return []
        
        if self.use_chroma:
            results = self._collection.query(
                query_embeddings=[query_emb],
                n_results=k
            )
            
            output = []
            for i, doc_id in enumerate(results['ids'][0]):
                # ChromaDB returns distance, convert to similarity
                score = 1 - results['distances'][0][i] if results.get('distances') else 0.7
                
                if score >= threshold:
                    meta = results['metadatas'][0][i] if results.get('metadatas') else {}
                    output.append(RetrievalResult(
                        chunk_id=doc_id,
                        content=results['documents'][0][i],
                        source="absher",
                        category=meta.get('category', ''),
                        score=round(score, 4),
                        metadata=meta
                    ))
            return output
        
        else:
            # In-memory search
            scores = []
            for i, emb in enumerate(self.embeddings):
                score = self._cosine(query_emb, emb)
                if score >= threshold:
                    scores.append((i, score))
            
            scores.sort(key=lambda x: x[1], reverse=True)
            
            output = []
            for idx, score in scores[:k]:
                doc = self.docs[idx]
                output.append(RetrievalResult(
                    chunk_id=doc.id,
                    content=doc.content,
                    source="absher",
                    category=doc.category,
                    score=round(score, 4),
                    metadata=doc.metadata
                ))
            return output
    
    def search_by_category(self, query: str, category: str, k: int = 5) -> List[RetrievalResult]:
        """بحث في فئة محددة"""
        results = self.search(query, k=k*2, threshold=0.3)
        filtered = [r for r in results if r.category == category]
        return filtered[:k]
    
    def count(self) -> int:
        """عدد المستندات"""
        if self.use_chroma:
            return self._collection.count()
        return len(self.docs)
    
    def stats(self) -> Dict:
        """إحصائيات"""
        if self.use_chroma:
            return {
                "count": self._collection.count(),
                "storage": "chromadb"
            }
        
        categories = {}
        for doc in self.docs:
            categories[doc.category] = categories.get(doc.category, 0) + 1
        
        return {
            "count": len(self.docs),
            "storage": "in-memory",
            "categories": categories
        }
    
    def clear(self):
        """مسح القاعدة"""
        if self.use_chroma:
            self._chromadb.delete_collection("absher_kb")
            self._collection = self._chromadb.create_collection(
                name="absher_kb",
                metadata={"hnsw:space": "cosine"}
            )
        else:
            self.docs = []
            self.embeddings = []


class DataIngestion:
    """تجهيز وتقسيم البيانات"""
    
    def __init__(self, chunk_size: int = 500, overlap: int = 50):
        self.chunk_size = chunk_size
        self.overlap = overlap
    
    def clean(self, text: str) -> str:
        """تنظيف النص"""
        import re
        text = re.sub(r'\s+', ' ', text)
        return text.strip()
    
    def chunk(self, text: str) -> List[str]:
        """تقسيم النص"""
        text = self.clean(text)
        
        if len(text) <= self.chunk_size:
            return [text]
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = start + self.chunk_size
            
            # البحث عن نهاية جملة
            if end < len(text):
                for sep in ['. ', '، ', '؟ ', '! ', '\n']:
                    last_sep = text.rfind(sep, start, end)
                    if last_sep > start:
                        end = last_sep + 1
                        break
            
            chunks.append(text[start:end].strip())
            start = end - self.overlap if end < len(text) else end
        
        return chunks
    
    def process_content(self, items: List[Dict]) -> List[Dict]:
        """معالجة المحتوى للفهرسة"""
        processed = []
        
        for item in items:
            content = item.get("content", "")
            chunks = self.chunk(content)
            
            for i, chunk in enumerate(chunks):
                processed.append({
                    "content": chunk,
                    "category": item.get("category", ""),
                    "title": item.get("title", ""),
                    "metadata": {
                        "source_id": item.get("id", ""),
                        "chunk_index": i,
                        "total_chunks": len(chunks)
                    }
                })
        
        return processed


if __name__ == "__main__":
    from ollama_client import OllamaClient
    
    print("=" * 50)
    print("🗄️ Vector Database Test")
    print("=" * 50)
    
    client = OllamaClient()
    
    if not client.is_available():
        print("⚠ Ollama not running. Start with: ollama serve")
    else:
        db = VectorDB(client)
        
        # إضافة تجريبية
        db.add("تجديد جواز السفر يتطلب صورة شخصية وهوية سارية", "الجوازات", "تجديد الجواز")
        db.add("رخصة القيادة تجدد إلكترونياً عبر أبشر", "المرور", "تجديد الرخصة")
        
        print(f"\n📊 Stats: {db.stats()}")
        
        # بحث
        results = db.search("كيف أجدد الجواز؟", k=2)
        print(f"\n🔍 Search results:")
        for r in results:
            print(f"   [{r.category}] {r.content[:50]}... (score: {r.score})")
