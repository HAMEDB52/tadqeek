"""
Ollama Client - Optimized for RTX 5070 Ti (16GB VRAM)
=====================================================
النماذج الموصى بها:
- LLM: qwen2.5:14b (أفضل للعربية) أو llama3.2
- Embeddings: nomic-embed-text
- Vision: llama3.2-vision أو llava:13b
"""

import json
import urllib.request
import urllib.error
from typing import List, Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class OllamaConfig:
    """إعدادات Ollama للـ RTX 5070 Ti 16GB"""
    host: str = "http://localhost:11434"
    
    # النماذج الموصى بها (خفيفة ~6GB)
    llm_model: str = "qwen2.5:7b"             # 4.4GB - جيد للعربية
    embed_model: str = "nomic-embed-text"     # 274MB - embeddings
    vision_model: str = "moondream"           # 1.7GB - OCR/vision
    
    # إعدادات الأداء
    temperature: float = 0.3
    top_p: float = 0.9
    num_ctx: int = 4096
    num_gpu: int = 99  # كل الـ layers على GPU
    
    # بدائل أثقل (للجودة العالية)
    llm_heavy: str = "qwen2.5:14b"            # 8.9GB أفضل دقة
    vision_heavy: str = "llama3.2-vision"     # 2GB أفضل OCR


class OllamaClient:
    """عميل Ollama مع GPU"""
    
    def __init__(self, config: OllamaConfig = None):
        self.config = config or OllamaConfig()
        self.base_url = self.config.host
    
    def _post(self, endpoint: str, data: Dict) -> Dict:
        """POST request"""
        url = f"{self.base_url}/{endpoint}"
        req = urllib.request.Request(
            url,
            data=json.dumps(data).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.URLError as e:
            raise ConnectionError(f"Ollama غير متصل: {e}")
    
    def _get(self, endpoint: str) -> Dict:
        """GET request"""
        url = f"{self.base_url}/{endpoint}"
        req = urllib.request.Request(url)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except:
            return {}
    
    # === Connection ===
    
    def is_available(self) -> bool:
        """التحقق من الاتصال"""
        try:
            self._get("api/tags")
            return True
        except:
            return False
    
    def list_models(self) -> List[str]:
        """قائمة النماذج"""
        data = self._get("api/tags")
        return [m['name'] for m in data.get('models', [])]
    
    def pull(self, model: str) -> bool:
        """تحميل نموذج"""
        try:
            self._post("api/pull", {"name": model})
            return True
        except:
            return False
    
    # === Embeddings ===
    
    def embed(self, text: str, model: str = None) -> List[float]:
        """embedding لنص"""
        model = model or self.config.embed_model
        result = self._post("api/embeddings", {"model": model, "prompt": text})
        return result.get("embedding", [])
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        """embeddings متعددة"""
        return [self.embed(t) for t in texts]
    
    # === Generation ===
    
    def generate(self, prompt: str, model: str = None, system: str = None) -> str:
        """توليد نص"""
        model = model or self.config.llm_model
        data = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": self.config.temperature,
                "num_ctx": self.config.num_ctx,
                "num_gpu": self.config.num_gpu
            }
        }
        if system:
            data["system"] = system
        
        result = self._post("api/generate", data)
        return result.get("response", "")
    
    def chat(self, messages: List[Dict], model: str = None) -> str:
        """محادثة"""
        model = model or self.config.llm_model
        data = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {"num_gpu": self.config.num_gpu}
        }
        result = self._post("api/chat", data)
        return result.get("message", {}).get("content", "")
    
    # === Vision ===
    
    def vision(self, image_b64: str, prompt: str, model: str = None) -> str:
        """تحليل صورة"""
        model = model or self.config.vision_model
        data = {
            "model": model,
            "prompt": prompt,
            "images": [image_b64],
            "stream": False,
            "options": {"num_gpu": self.config.num_gpu}
        }
        result = self._post("api/generate", data)
        return result.get("response", "")
    
    # === Arabic Helpers ===
    
    def arabic(self, prompt: str, task: str = "general") -> str:
        """توليد عربي محسّن"""
        systems = {
            "general": "أنت مساعد ذكي للخدمات الحكومية السعودية. أجب بالعربية بشكل مختصر.",
            "ocr": "استخرج البيانات من الصورة بدقة. أعد JSON فقط.",
            "classify": "صنف الطلب وحدد الخدمة المطلوبة.",
            "summarize": "لخص المعلومات بشكل واضح ومنظم."
        }
        return self.generate(prompt, system=systems.get(task, systems["general"]))


def check_gpu():
    """معلومات GPU"""
    try:
        import subprocess
        r = subprocess.run(
            ['nvidia-smi', '--query-gpu=name,memory.total,memory.free', '--format=csv,noheader,nounits'],
            capture_output=True, text=True
        )
        if r.returncode == 0:
            parts = r.stdout.strip().split(', ')
            return {"gpu": parts[0], "vram_total": f"{parts[1]}MB", "vram_free": f"{parts[2]}MB"}
    except:
        pass
    return {"gpu": "RTX 5070 Ti (assumed)", "vram_total": "16GB"}


def recommended_models(vram_gb: int = 16) -> Dict:
    """النماذج الموصى بها"""
    if vram_gb >= 16:
        return {
            "llm": "qwen2.5:14b",       # أفضل للعربية
            "embed": "nomic-embed-text",
            "vision": "llama3.2-vision",
            "note": "16GB - يمكن تشغيل 14B models"
        }
    elif vram_gb >= 8:
        return {
            "llm": "llama3.2",
            "embed": "nomic-embed-text", 
            "vision": "llava:7b",
            "note": "8GB - 7B models فقط"
        }
    return {"llm": "llama3.2:1b", "embed": "nomic-embed-text", "vision": "llava:7b"}


# === Setup Script ===

SETUP_COMMANDS = """
# تثبيت النماذج المطلوبة لـ RTX 5070 Ti 16GB:

ollama pull qwen2.5:14b          # LLM للعربية (8.9GB)
ollama pull nomic-embed-text     # Embeddings (274MB)
ollama pull llama3.2-vision      # Vision/OCR (2.0GB)

# بدائل أخف:
ollama pull llama3.2             # LLM خفيف (2.0GB)
ollama pull llava:7b             # Vision خفيف (4.7GB)
"""


if __name__ == "__main__":
    print("=" * 50)
    print("🖥️ Ollama Client - RTX 5070 Ti Optimized")
    print("=" * 50)
    
    print(f"\n📊 GPU: {check_gpu()}")
    print(f"\n📋 Recommended: {recommended_models(16)}")
    
    client = OllamaClient()
    status = "✓ Connected" if client.is_available() else "✗ Not Running"
    print(f"\n🔌 Ollama: {status}")
    
    if client.is_available():
        models = client.list_models()
        print(f"   Models: {models[:5]}")
    
    print(f"\n📝 Setup Commands:\n{SETUP_COMMANDS}")
