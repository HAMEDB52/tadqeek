"""
مساعد أبشر - Modern Chat Interface
"""

import streamlit as st
import json
import re
import urllib.request
import base64

# DB
try:
    from db_manager import get_db
    from wakala_advisor import WakalaAdvisor
    DB_OK = True
except:
    DB_OK = False

# Config
st.set_page_config(page_title="أبشر", page_icon="🔷", layout="centered")

OLLAMA = "http://localhost:11434"
MODEL = "qwen2.5:7b"

# ===================== CSS =====================
st.markdown("""
<style>
.stApp { background: #1a1a2e; }

#MainMenu, footer, header, .stDeployButton,
[data-testid="stSidebar"], [data-testid="collapsedControl"] { display: none !important; }

.block-container { max-width: 700px !important; padding: 1rem !important; }

/* Header */
.header {
    text-align: center;
    padding: 25px 0;
}

.header .logo {
    width: 56px; height: 56px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 14px;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 26px; margin-bottom: 12px;
}

.header h1 { color: #fff; font-size: 22px; margin: 0; }
.header p { color: #888; font-size: 13px; margin: 6px 0 0 0; }

/* Chat */
.chat-box {
    background: #16162a;
    border-radius: 16px;
    padding: 16px;
    min-height: 420px;
    max-height: 420px;
    overflow-y: auto;
    margin-bottom: 16px;
}

/* Messages */
.msg { margin: 14px 0; display: flex; gap: 10px; }
.msg.user { flex-direction: row-reverse; }

.av {
    width: 34px; height: 34px;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px; flex-shrink: 0;
}
.msg.user .av { background: #667eea; }
.msg.bot .av { background: #2d2d44; }

.bub {
    padding: 12px 16px;
    border-radius: 14px;
    max-width: 78%;
    font-size: 14px;
    line-height: 1.6;
    color: #e0e0e0;
}
.msg.user .bub { background: #667eea; color: #fff; border-radius: 14px 14px 4px 14px; }
.msg.bot .bub { background: #2d2d44; border-radius: 14px 14px 14px 4px; }

/* Cards */
.card {
    background: #1a1a2e;
    border-radius: 10px;
    padding: 12px;
    margin: 8px 0;
}
.card.success { border-right: 3px solid #4ade80; }
.card.error { border-right: 3px solid #f87171; }
.card.warning { border-right: 3px solid #fbbf24; }
.card.info { border-right: 3px solid #667eea; }

.card h4 { color: #a78bfa; font-size: 13px; margin: 0 0 6px 0; }
.card p { color: #9ca3af; font-size: 12px; margin: 3px 0; }

/* Profile */
.profile {
    background: #1a1a2e;
    border-radius: 10px;
    padding: 12px;
    margin: 8px 0;
}
.profile .name { color: #a78bfa; font-weight: 600; font-size: 14px; margin-bottom: 8px; }
.profile .row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #2d2d44; font-size: 12px; }
.profile .row:last-child { border: none; }
.profile .label { color: #6b7280; }
.profile .value { color: #d1d5db; }

/* Docs */
.doc { display: flex; justify-content: space-between; padding: 6px 8px; background: #2d2d44; border-radius: 6px; margin: 4px 0; font-size: 12px; }
.doc .name { color: #d1d5db; }
.badge { padding: 2px 8px; border-radius: 8px; font-size: 10px; font-weight: 600; }
.badge.ok { background: #166534; color: #4ade80; }
.badge.bad { background: #7f1d1d; color: #fca5a5; }
.badge.warn { background: #78350f; color: #fcd34d; }

/* Input */
.input-area {
    background: #16162a;
    border-radius: 14px;
    padding: 14px;
}

.stTextInput > div > div > input {
    background: #2d2d44 !important;
    border: none !important;
    border-radius: 10px !important;
    color: #fff !important;
    padding: 14px !important;
    font-size: 14px !important;
}
.stTextInput > div > div > input::placeholder { color: #6b7280 !important; }
.stTextInput > div > div > input:focus { box-shadow: 0 0 0 2px #667eea !important; }

[data-testid="stForm"] { background: transparent !important; border: none !important; padding: 0 !important; }

.stFormSubmitButton > button {
    background: linear-gradient(135deg, #667eea, #764ba2) !important;
    border: none !important; border-radius: 10px !important;
    color: #fff !important; padding: 14px 24px !important;
    font-weight: 600 !important; font-size: 14px !important;
}

.stButton > button {
    background: #2d2d44 !important;
    border: none !important; border-radius: 8px !important;
    color: #9ca3af !important; font-size: 12px !important;
}

/* Upload Button - Visible */
[data-testid="stFileUploader"] {
    background: #2d2d44 !important;
    border: 2px dashed #667eea !important;
    border-radius: 10px !important;
    padding: 12px !important;
    margin-bottom: 12px !important;
}

[data-testid="stFileUploader"] label {
    color: #a78bfa !important;
    font-size: 13px !important;
}

[data-testid="stFileUploader"] label p {
    color: #a78bfa !important;
}

[data-testid="stFileUploader"] section {
    background: transparent !important;
    padding: 8px !important;
}

[data-testid="stFileUploader"] button {
    background: #667eea !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
}

[data-testid="stFileUploader"] small,
[data-testid="stFileUploader"] span {
    color: #9ca3af !important;
    font-size: 11px !important;
}

[data-testid="stFileUploaderDropzoneInstructions"] div {
    color: #9ca3af !important;
}

/* Scrollbar */
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }

/* Image preview */
.img-preview {
    background: #2d2d44;
    border-radius: 10px;
    padding: 10px;
    margin: 10px 0;
    text-align: center;
}
.img-preview img { border-radius: 8px; max-width: 200px; }
.img-preview p { color: #9ca3af; font-size: 12px; margin: 8px 0 0 0; }
</style>
""", unsafe_allow_html=True)

# ===================== STATE =====================
if 'msgs' not in st.session_state:
    st.session_state.msgs = []
if 'citizen' not in st.session_state:
    st.session_state.citizen = None
if 'db' not in st.session_state:
    st.session_state.db = get_db() if DB_OK else None
if 'advisor' not in st.session_state:
    st.session_state.advisor = WakalaAdvisor() if DB_OK else None
if 'pending_renewal' not in st.session_state:
    st.session_state.pending_renewal = None
if 'uploaded_img' not in st.session_state:
    st.session_state.uploaded_img = None

# ===================== FUNCTIONS =====================
def ollama_chat(messages):
    try:
        data = {"model": MODEL, "messages": messages, "stream": False}
        req = urllib.request.Request(
            f"{OLLAMA}/api/chat",
            data=json.dumps(data).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        with urllib.request.urlopen(req, timeout=120) as r:
            res = json.loads(r.read().decode('utf-8'))
            return res.get("message", {}).get("content", "")
    except:
        return None

def get_id(t):
    m = re.search(r'\b[12]\d{9}\b', t)
    return m.group() if m else None

def detect_renewal_intent(text):
    """Detect what document user wants to renew"""
    text = text.lower()
    
    # National ID
    if any(w in text for w in ['هوية', 'هويتي', 'الهوية', 'هويه']):
        return 'national_id', 'الهوية الوطنية'
    
    # Passport
    if any(w in text for w in ['جواز', 'جوازي', 'الجواز', 'سفر']):
        return 'passport', 'جواز السفر'
    
    # License
    if any(w in text for w in ['رخصة', 'رخصتي', 'الرخصة', 'قيادة', 'رخصه']):
        return 'driving_license', 'رخصة القيادة'
    
    # Vehicle
    if any(w in text for w in ['استمارة', 'سيارة', 'مركبة', 'استماره']):
        return 'vehicle_registration', 'استمارة المركبة'
    
    return None, None

def detect_confirmation(text):
    """Detect if user confirmed"""
    text = text.lower()
    confirms = ['نعم', 'اي', 'ايه', 'اكيد', 'تمام', 'موافق', 'اوكي', 'ok', 'yes', 'صحيح', 'ابيه', 'ابغاه', 'جدد', 'جددها']
    return any(w in text for w in confirms)

def detect_wakala_intent(text):
    """Detect wakala/power of attorney request and purpose"""
    text_lower = text.lower()
    
    # Check if asking about wakala
    wakala_words = ['وكالة', 'توكيل', 'وكاله', 'توكل', 'اوكل', 'وكيل']
    if not any(w in text_lower for w in wakala_words):
        return None, None
    
    # Detect purpose
    if any(w in text_lower for w in ['سيارة', 'سياره', 'مركبة', 'بيع سيارة']):
        return 'بيع_سيارة', 'بيع سيارة'
    if any(w in text_lower for w in ['عقار', 'بيت', 'ارض', 'أرض', 'شقة', 'شقه']):
        return 'بيع_عقار', 'بيع عقار'
    if any(w in text_lower for w in ['استلام', 'استلم', 'تسلم']):
        return 'استلام', 'استلام مستندات'
    if any(w in text_lower for w in ['محكمة', 'قضية', 'قضائي']):
        return 'قضائية', 'التمثيل القضائي'
    if any(w in text_lower for w in ['عام', 'عامة', 'عامه', 'كل شي', 'كل شيء']):
        return 'عامة', 'وكالة عامة'
    
    # General wakala question
    return 'سؤال', None

def get_wakala_advice(wakala_type, purpose, advisor):
    """Get wakala advice from advisor"""
    
    if wakala_type == 'سؤال':
        return '''أنصحك دائماً بالوكالة الخاصة بدلاً من العامة.

<div class="card info">
<h4>📋 أنواع الوكالات</h4>
<p><b>وكالة خاصة ✅</b> - الأفضل والأكثر أماناً</p>
<p>محددة بغرض واحد فقط مثل: بيع سيارة، استلام مستندات</p>
<p><b>وكالة عامة ⚠️</b> - خطرة جداً</p>
<p>تعطي الوكيل صلاحيات واسعة قد تُستغل</p>
</div>

ما الغرض من الوكالة التي تحتاجها؟ (مثال: بيع سيارة، استلام وثيقة)'''
    
    if wakala_type == 'عامة':
        info = advisor.explain_type("عامة")
        return f'''<div class="card error">
<h4>⛔ تحذير: الوكالة العامة خطرة!</h4>
<p>{info["warning"]}</p>
<p><b>النصيحة:</b> {info["recommendation"]}</p>
</div>

أنصحك بوكالة خاصة بدلاً منها. ما الغرض الذي تحتاج الوكالة له؟'''
    
    # Get safe template
    template = advisor.suggest_safe_wakala(purpose)
    risk_info = advisor.explain_type("خاصة")
    
    return f'''<div class="card success">
<h4>✅ أنصحك بوكالة خاصة لـ {purpose}</h4>
<p>{risk_info["recommendation"]}</p>
</div>

<div class="card">
<h4>📝 نموذج الوكالة المقترح</h4>
<p style="font-family: monospace; white-space: pre-wrap; font-size: 11px;">{template}</p>
</div>

<div class="card warning">
<h4>⚠️ نصائح مهمة</h4>
<p>• حدد مدة الوكالة (لا تتجاوز سنة)</p>
<p>• لا تضف عبارة "كافة الصلاحيات"</p>
<p>• احتفظ بنسخة من الوكالة</p>
</div>'''

def profile_html(c):
    return f'''<div class="profile">
<div class="name">👤 {c['name_ar']}</div>
<div class="row"><span class="label">الهوية</span><span class="value">{c['id_number']}</span></div>
<div class="row"><span class="label">الجوال</span><span class="value">{c['phone']}</span></div>
<div class="row"><span class="label">المدينة</span><span class="value">{c['address']['city']}</span></div>
</div>'''

def docs_html(cid):
    db = st.session_state.db
    docs = db.get_citizen_documents_status(cid)
    if not docs: return ""
    html = '<div class="card"><h4>📄 المستندات</h4>'
    for d in docs:
        cls = {"valid":"ok","expired":"bad","expiring_soon":"warn"}.get(d.status,"")
        txt = {"valid":"ساري","expired":"منتهي","expiring_soon":"قارب"}.get(d.status,"")
        html += f'<div class="doc"><span class="name">{d.name}</span><span class="badge {cls}">{txt}</span></div>'
    return html + '</div>'

def process(text, has_image=False):
    db = st.session_state.db
    advisor = st.session_state.advisor
    
    # Check for ID number
    id_num = get_id(text)
    if id_num:
        c = db.get_citizen(id_num)
        if c:
            st.session_state.citizen = c
            exp = db.get_expired_documents(id_num)
            r = f"أهلاً {c['name_ar']} 👋<br><br>"
            r += profile_html(c)
            r += docs_html(id_num)
            if exp:
                r += f'<div class="card warning"><h4>⚠️ مستندات منتهية</h4><p>{", ".join(exp)}</p><p>هل تريد تجديد أي منها؟</p></div>'
            return r
        return '<div class="card error"><h4>❌</h4><p>رقم الهوية غير موجود في النظام</p></div>'
    
    # Check for pending renewal with image
    if st.session_state.pending_renewal and has_image:
        doc_type, doc_name = st.session_state.pending_renewal
        if st.session_state.citizen:
            result = db.renew_document(st.session_state.citizen["id_number"], doc_type)
            st.session_state.pending_renewal = None
            if result["success"]:
                st.session_state.citizen = db.get_citizen(st.session_state.citizen["id_number"])
                return f'''تم استلام صورة {doc_name} ✓

<div class="card success">
<h4>✅ تم التجديد بنجاح</h4>
<p>رقم الطلب: {result["request_id"]}</p>
<p>تاريخ الانتهاء الجديد: {result["new_expiry"]}</p>
</div>

هل تحتاج مساعدة في شيء آخر؟'''
    
    # Check for confirmation of pending renewal
    if st.session_state.pending_renewal and detect_confirmation(text):
        doc_type, doc_name = st.session_state.pending_renewal
        return f'''ممتاز! لإكمال تجديد {doc_name}:

<div class="card info">
<h4>📸 مطلوب صورة المستند</h4>
<p>الرجاء رفع صورة {doc_name} الحالية</p>
<p>استخدم زر "رفع صورة المستند" في الأسفل</p>
</div>'''
    
    # Check for wakala intent BEFORE renewal intent
    wakala_type, purpose = detect_wakala_intent(text)
    if wakala_type and advisor:
        return get_wakala_advice(wakala_type, purpose, advisor)
    
    # Check for renewal intent
    doc_type, doc_name = detect_renewal_intent(text)
    if doc_type:
        if not st.session_state.citizen:
            return '''<div class="card warning">
<h4>⚠️ تحتاج تسجيل الدخول أولاً</h4>
<p>الرجاء إدخال رقم هويتك للمتابعة</p>
</div>'''
        
        # Set pending renewal
        st.session_state.pending_renewal = (doc_type, doc_name)
        
        return f'''فهمت، تريد تجديد {doc_name} 📋

<div class="card info">
<h4>📸 مطلوب صورة المستند</h4>
<p>لإتمام عملية التجديد، أحتاج صورة {doc_name} الحالية</p>
<p>استخدم زر "رفع صورة المستند" في الأسفل</p>
</div>

بعد رفع الصورة سأتحقق من البيانات وأكمل التجديد.'''
    
    # Default - use LLM
    msgs = [{"role":"system","content":f"""أنت مساعد أبشر للخدمات الحكومية السعودية.

قواعد صارمة جداً:
1. تحدث بالعربية فقط - لا تستخدم أي لغة أخرى مطلقاً
2. لا تطلب من المستخدم زيارة أي مبنى أو موقع - كل الخدمات تتم من خلالي
3. كن مختصراً ومباشراً

الخدمات المتاحة:
- تجديد الهوية الوطنية (يحتاج رفع صورة)
- تجديد جواز السفر (يحتاج رفع صورة)
- تجديد رخصة القيادة (يحتاج رفع صورة)
- تجديد استمارة المركبة (يحتاج رفع صورة)
- إصدار وكالة شرعية

للوكالات:
- الوكالة الخاصة آمنة ومحددة الغرض (أنصح بها دائماً)
- الوكالة العامة خطرة جداً (لا أنصح بها)

إذا سأل عن تجديد: أخبره أن يرفع صورة المستند
إذا سأل عن وكالة: انصحه بالوكالة الخاصة

{"المواطن: " + st.session_state.citizen['name_ar'] if st.session_state.citizen else "لم يسجل دخول"}

تذكر: الرد بالعربية فقط!"""}]
    
    for m in st.session_state.msgs[-4:]:
        content = re.sub(r'<[^>]+>', '', str(m.get("c","")))
        if content:
            msgs.append({"role":"user" if m["r"]=="user" else "assistant", "content":content})
    
    msgs.append({"role":"user","content":text})
    
    resp = ollama_chat(msgs)
    if not resp:
        return '<div class="card error"><h4>⚠️</h4><p>تأكد من تشغيل Ollama</p></div>'
    
    return resp

# ===================== UI =====================

# Header
st.markdown('''
<div class="header">
    <div class="logo">🔷</div>
    <h1>مساعد أبشر</h1>
    <p>خدماتك الحكومية بالذكاء الاصطناعي</p>
</div>
''', unsafe_allow_html=True)

# Chat
st.markdown('<div class="chat-box">', unsafe_allow_html=True)

if not st.session_state.msgs:
    st.markdown('''
<div class="msg bot">
    <div class="av">🔷</div>
    <div class="bub">
        أهلاً بك! 👋<br><br>
        أقدر أساعدك في تجديد الهوية، الجواز، الرخصة، أو الاستمارة.<br><br>
        أدخل رقم هويتك للبدء 🔢
    </div>
</div>
''', unsafe_allow_html=True)

for m in st.session_state.msgs:
    cls = "user" if m["r"] == "user" else "bot"
    av = "👤" if m["r"] == "user" else "🔷"
    st.markdown(f'''
<div class="msg {cls}">
    <div class="av">{av}</div>
    <div class="bub">{m["c"]}</div>
</div>''', unsafe_allow_html=True)

st.markdown('</div>', unsafe_allow_html=True)

# Input Area
st.markdown('<div class="input-area">', unsafe_allow_html=True)

# File uploader (visible)
uploaded = st.file_uploader("📎 رفع صورة المستند", type=['png','jpg','jpeg'], key="upload")

if uploaded:
    st.image(uploaded, width=150)
    st.success(f"✓ تم رفع: {uploaded.name}")

# Text input form
with st.form("chat_form", clear_on_submit=True):
    col1, col2 = st.columns([5, 1])
    with col1:
        user_text = st.text_input("msg", placeholder="اكتب رسالتك هنا...", label_visibility="collapsed")
    with col2:
        submitted = st.form_submit_button("إرسال")

if submitted and user_text:
    has_img = uploaded is not None
    
    display_msg = user_text
    if has_img:
        display_msg = f"📎 {uploaded.name}<br>{user_text}"
    
    st.session_state.msgs.append({"r": "user", "c": display_msg})
    
    response = process(user_text, has_image=has_img)
    st.session_state.msgs.append({"r": "bot", "c": response})
    
    st.rerun()

st.markdown('</div>', unsafe_allow_html=True)

# Reset button
col1, col2, col3 = st.columns([1, 1, 1])
with col2:
    if st.button("🔄 محادثة جديدة"):
        st.session_state.msgs = []
        st.session_state.citizen = None
        st.session_state.pending_renewal = None
        st.rerun()