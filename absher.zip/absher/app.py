"""
مساعد أبشر - LLM-First Architecture
All user input goes through LLM with function calling
"""

import streamlit as st
import json
import re
import urllib.request
from datetime import datetime

# DB & Advisor
try:
    from db_manager import get_db
    from wakala_advisor import WakalaAdvisor
    DB_OK = True
except:
    DB_OK = False

# Config
st.set_page_config(page_title="أبشر", page_icon="🔷", layout="centered")

OLLAMA = "http://localhost:11434"
MODEL = "qwen2.5:7b"

# ===================== CSS =====================
st.markdown("""
<style>
.stApp { background: #1a1a2e; }
#MainMenu, footer, header, .stDeployButton, [data-testid="stSidebar"] { display: none !important; }
.block-container { max-width: 700px !important; padding: 1rem !important; }

.header { text-align: center; padding: 25px 0; }
.header .logo {
    width: 56px; height: 56px;
    background: linear-gradient(135deg, #667eea, #764ba2);
    border-radius: 14px;
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 26px; margin-bottom: 12px;
}
.header h1 { color: #fff; font-size: 22px; margin: 0; }
.header p { color: #888; font-size: 13px; margin: 6px 0 0 0; }

.chat-box {
    background: #16162a; border-radius: 16px; padding: 16px;
    min-height: 420px; max-height: 420px; overflow-y: auto; margin-bottom: 16px;
}

.msg { margin: 14px 0; display: flex; gap: 10px; }
.msg.user { flex-direction: row-reverse; }
.av {
    width: 34px; height: 34px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 15px; flex-shrink: 0;
}
.msg.user .av { background: #667eea; }
.msg.bot .av { background: #2d2d44; }
.bub {
    padding: 12px 16px; border-radius: 14px; max-width: 78%;
    font-size: 14px; line-height: 1.6; color: #e0e0e0;
}
.msg.user .bub { background: #667eea; color: #fff; border-radius: 14px 14px 4px 14px; }
.msg.bot .bub { background: #2d2d44; border-radius: 14px 14px 14px 4px; }

.card { background: #1a1a2e; border-radius: 10px; padding: 12px; margin: 8px 0; }
.card.success { border-right: 3px solid #4ade80; }
.card.error { border-right: 3px solid #f87171; }
.card.warning { border-right: 3px solid #fbbf24; }
.card.info { border-right: 3px solid #667eea; }
.card h4 { color: #a78bfa; font-size: 13px; margin: 0 0 6px 0; }
.card p { color: #9ca3af; font-size: 12px; margin: 3px 0; }

.profile { background: #1a1a2e; border-radius: 10px; padding: 12px; margin: 8px 0; }
.profile .name { color: #a78bfa; font-weight: 600; font-size: 14px; margin-bottom: 8px; }
.profile .row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #2d2d44; font-size: 12px; }
.profile .row:last-child { border: none; }
.profile .label { color: #6b7280; }
.profile .value { color: #d1d5db; }

.doc { display: flex; justify-content: space-between; padding: 6px 8px; background: #2d2d44; border-radius: 6px; margin: 4px 0; font-size: 12px; }
.doc .name { color: #d1d5db; }
.badge { padding: 2px 8px; border-radius: 8px; font-size: 10px; font-weight: 600; }
.badge.ok { background: #166534; color: #4ade80; }
.badge.bad { background: #7f1d1d; color: #fca5a5; }
.badge.warn { background: #78350f; color: #fcd34d; }

.input-area { background: #16162a; border-radius: 14px; padding: 14px; }
.stTextInput > div > div > input {
    background: #2d2d44 !important; border: none !important; border-radius: 10px !important;
    color: #fff !important; padding: 14px !important; font-size: 14px !important;
}
.stTextInput > div > div > input::placeholder { color: #6b7280 !important; }
.stTextInput > div > div > input:focus { box-shadow: 0 0 0 2px #667eea !important; }
[data-testid="stForm"] { background: transparent !important; border: none !important; padding: 0 !important; }
.stFormSubmitButton > button {
    background: linear-gradient(135deg, #667eea, #764ba2) !important;
    border: none !important; border-radius: 10px !important;
    color: #fff !important; padding: 14px 24px !important; font-weight: 600 !important;
}
.stButton > button { background: #2d2d44 !important; border: none !important; border-radius: 8px !important; color: #9ca3af !important; }

[data-testid="stFileUploader"] {
    background: #2d2d44 !important; border: 2px dashed #667eea !important;
    border-radius: 10px !important; padding: 12px !important; margin-bottom: 12px !important;
}
[data-testid="stFileUploader"] label, [data-testid="stFileUploader"] label p { color: #a78bfa !important; font-size: 13px !important; }
[data-testid="stFileUploader"] button { background: #667eea !important; color: #fff !important; border: none !important; border-radius: 8px !important; }
[data-testid="stFileUploader"] small, [data-testid="stFileUploader"] span { color: #9ca3af !important; font-size: 11px !important; }

::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: #4b5563; border-radius: 3px; }
</style>
""", unsafe_allow_html=True)

# ===================== STATE =====================
if 'msgs' not in st.session_state:
    st.session_state.msgs = []
if 'citizen' not in st.session_state:
    st.session_state.citizen = None
if 'db' not in st.session_state:
    st.session_state.db = get_db() if DB_OK else None
if 'advisor' not in st.session_state:
    st.session_state.advisor = WakalaAdvisor() if DB_OK else None
if 'pending_action' not in st.session_state:
    st.session_state.pending_action = None

# ===================== FUNCTIONS (Tools) =====================

def fn_login(id_number: str) -> dict:
    """تسجيل دخول المواطن"""
    db = st.session_state.db
    c = db.get_citizen(id_number)
    if c:
        st.session_state.citizen = c
        exp = db.get_expired_documents(id_number)
        return {"success": True, "citizen": c, "expired_docs": exp}
    return {"success": False, "error": "رقم الهوية غير موجود"}

def fn_get_profile() -> dict:
    """الحصول على بيانات المواطن"""
    if st.session_state.citizen:
        c = st.session_state.citizen
        db = st.session_state.db
        docs = db.get_citizen_documents_status(c["id_number"])
        exp = db.get_expired_documents(c["id_number"])
        return {
            "success": True,
            "name": c["name_ar"],
            "id": c["id_number"],
            "phone": c["phone"],
            "city": c["address"]["city"],
            "documents": [{"name": d.name, "status": d.status} for d in docs],
            "expired": exp
        }
    return {"success": False, "error": "لم يتم تسجيل الدخول"}

def fn_request_renewal(doc_type: str) -> dict:
    """طلب تجديد مستند"""
    if not st.session_state.citizen:
        return {"success": False, "error": "سجل دخولك أولاً برقم الهوية"}
    
    doc_names = {
        "national_id": "الهوية الوطنية",
        "passport": "جواز السفر",
        "driving_license": "رخصة القيادة",
        "vehicle_registration": "استمارة المركبة"
    }
    
    if doc_type not in doc_names:
        return {"success": False, "error": "نوع المستند غير معروف"}
    
    st.session_state.pending_action = {"type": "renewal", "doc_type": doc_type}
    return {"success": True, "message": f"لتجديد {doc_names[doc_type]}، ارفع صورة المستند الحالي", "needs_image": True}

def fn_complete_renewal() -> dict:
    """إكمال التجديد بعد رفع الصورة"""
    if not st.session_state.pending_action or st.session_state.pending_action["type"] != "renewal":
        return {"success": False, "error": "لا يوجد طلب تجديد قيد الانتظار"}
    
    db = st.session_state.db
    doc_type = st.session_state.pending_action["doc_type"]
    result = db.renew_document(st.session_state.citizen["id_number"], doc_type)
    st.session_state.pending_action = None
    
    if result["success"]:
        st.session_state.citizen = db.get_citizen(st.session_state.citizen["id_number"])
        return {
            "success": True,
            "request_id": result["request_id"],
            "new_expiry": result["new_expiry"]
        }
    return {"success": False, "error": "فشل التجديد"}

def fn_wakala_advice(wakala_type: str, purpose: str = None) -> dict:
    """نصيحة عن الوكالات"""
    advisor = st.session_state.advisor
    
    if wakala_type == "عامة":
        return {
            "type": "عامة",
            "risk": "حرج",
            "warning": "الوكالة العامة خطرة جداً! تمنح صلاحيات واسعة قد تشمل بيع كل ممتلكاتك",
            "recommendation": "أنصحك بوكالة خاصة محددة الغرض بدلاً منها"
        }
    
    if purpose:
        template = advisor.suggest_safe_wakala(purpose)
        return {
            "type": "خاصة",
            "purpose": purpose,
            "risk": "منخفض",
            "template": template.strip(),
            "tips": ["حدد مدة الوكالة (لا تتجاوز سنة)", "لا تضف كافة الصلاحيات", "احتفظ بنسخة"]
        }
    
    return {
        "types": [
            {"name": "وكالة خاصة", "risk": "منخفض", "description": "محددة بغرض واحد - الأفضل والأكثر أماناً"},
            {"name": "وكالة عامة", "risk": "حرج", "description": "صلاحيات واسعة - خطرة جداً"}
        ],
        "recommendation": "ما الغرض من الوكالة؟ (بيع سيارة، استلام مستندات، إلخ)"
    }

def fn_get_services() -> dict:
    """قائمة الخدمات المتاحة"""
    return {
        "services": [
            "تجديد الهوية الوطنية",
            "تجديد جواز السفر", 
            "تجديد رخصة القيادة",
            "تجديد استمارة المركبة",
            "إصدار وكالة شرعية",
            "الاستعلام عن المستندات"
        ]
    }

# ===================== LLM SYSTEM PROMPT =====================
SYSTEM_PROMPT = """أنت مساعد أبشر الذكي للخدمات الحكومية السعودية.

# القواعد الصارمة:
1. تحدث بالعربية فقط - ممنوع أي لغة أخرى
2. أنت النظام نفسه - لا توجه المستخدم لأي موقع أو مكان آخر
3. استخدم الدوال المتاحة لتنفيذ الطلبات

# الدوال المتاحة:
- [LOGIN:رقم_الهوية] - تسجيل دخول (مثال: [LOGIN:1087654321])
- [PROFILE] - عرض بيانات المواطن المسجل
- [RENEW:نوع] - طلب تجديد (الأنواع: national_id, passport, driving_license, vehicle_registration)
- [COMPLETE_RENEWAL] - إكمال التجديد بعد رفع الصورة
- [WAKALA:نوع:الغرض] - نصيحة وكالة (مثال: [WAKALA:خاصة:بيع سيارة] أو [WAKALA:عامة])
- [SERVICES] - قائمة الخدمات

# كيفية الاستخدام:
- إذا أعطاك المستخدم رقم هوية (10 أرقام تبدأ بـ 1 أو 2) → استخدم [LOGIN:الرقم]
- إذا طلب تجديد هوية/جواز/رخصة/استمارة → استخدم [RENEW:النوع]
- إذا سأل عن وكالة/توكيل → استخدم [WAKALA:...]
- إذا رفع صورة وهناك طلب تجديد → استخدم [COMPLETE_RENEWAL]

# أمثلة:
- "1087654321" → أرد: "جاري تسجيل الدخول... [LOGIN:1087654321]"
- "أبغى أجدد هويتي" → "[RENEW:national_id]"
- "ودي أعطي أخوي توكيل يبيع سيارتي" → "[WAKALA:خاصة:بيع سيارة]"
- "وش الخدمات عندكم؟" → "[SERVICES]"

# الحالة الحالية:
{context}

# مهم:
- ضع الدالة في نهاية ردك
- اكتب رد قصير ودود قبل الدالة
- لا تشرح الدالة للمستخدم"""

# ===================== LLM CALL =====================
def call_llm(user_msg: str, has_image: bool = False) -> str:
    """Call LLM with context"""
    
    # Build context
    context_parts = []
    if st.session_state.citizen:
        c = st.session_state.citizen
        context_parts.append(f"المواطن: {c['name_ar']} ({c['id_number']})")
    else:
        context_parts.append("لم يسجل دخول")
    
    if st.session_state.pending_action:
        pa = st.session_state.pending_action
        if pa["type"] == "renewal":
            context_parts.append(f"في انتظار صورة لتجديد: {pa['doc_type']}")
    
    if has_image:
        context_parts.append("المستخدم رفع صورة")
    
    context = "\n".join(context_parts)
    
    # Build messages
    messages = [{"role": "system", "content": SYSTEM_PROMPT.format(context=context)}]
    
    # Add chat history (last 6 messages)
    for m in st.session_state.msgs[-6:]:
        content = re.sub(r'<[^>]+>', '', str(m.get("c", "")))
        if content:
            messages.append({
                "role": "user" if m["r"] == "user" else "assistant",
                "content": content[:500]
            })
    
    messages.append({"role": "user", "content": user_msg})
    
    try:
        data = {"model": MODEL, "messages": messages, "stream": False}
        req = urllib.request.Request(
            f"{OLLAMA}/api/chat",
            data=json.dumps(data).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        with urllib.request.urlopen(req, timeout=120) as r:
            res = json.loads(r.read().decode('utf-8'))
            return res.get("message", {}).get("content", "")
    except Exception as e:
        return f"ERROR:{str(e)}"

# ===================== FUNCTION EXECUTOR =====================
def execute_functions(response: str) -> tuple:
    """Parse and execute functions from LLM response"""
    
    results = []
    clean_response = response
    
    # LOGIN
    login_match = re.search(r'\[LOGIN:(\d{10})\]', response)
    if login_match:
        id_num = login_match.group(1)
        result = fn_login(id_num)
        results.append(("login", result))
        clean_response = re.sub(r'\[LOGIN:\d{10}\]', '', clean_response)
    
    # PROFILE
    if '[PROFILE]' in response:
        result = fn_get_profile()
        results.append(("profile", result))
        clean_response = clean_response.replace('[PROFILE]', '')
    
    # RENEW
    renew_match = re.search(r'\[RENEW:(\w+)\]', response)
    if renew_match:
        doc_type = renew_match.group(1)
        result = fn_request_renewal(doc_type)
        results.append(("renewal", result))
        clean_response = re.sub(r'\[RENEW:\w+\]', '', clean_response)
    
    # COMPLETE_RENEWAL
    if '[COMPLETE_RENEWAL]' in response:
        result = fn_complete_renewal()
        results.append(("complete_renewal", result))
        clean_response = clean_response.replace('[COMPLETE_RENEWAL]', '')
    
    # WAKALA
    wakala_match = re.search(r'\[WAKALA:([^:\]]+)(?::([^\]]+))?\]', response)
    if wakala_match:
        wtype = wakala_match.group(1)
        purpose = wakala_match.group(2)
        result = fn_wakala_advice(wtype, purpose)
        results.append(("wakala", result))
        clean_response = re.sub(r'\[WAKALA:[^\]]+\]', '', clean_response)
    
    # SERVICES
    if '[SERVICES]' in response:
        result = fn_get_services()
        results.append(("services", result))
        clean_response = clean_response.replace('[SERVICES]', '')
    
    return clean_response.strip(), results

# ===================== RENDER RESULTS =====================
def render_results(results: list) -> str:
    """Render function results as HTML"""
    html = ""
    
    for func_name, result in results:
        if func_name == "login":
            if result["success"]:
                c = result["citizen"]
                exp = result["expired_docs"]
                html += f'''<div class="profile">
<div class="name">👤 {c['name_ar']}</div>
<div class="row"><span class="label">الهوية</span><span class="value">{c['id_number']}</span></div>
<div class="row"><span class="label">الجوال</span><span class="value">{c['phone']}</span></div>
<div class="row"><span class="label">المدينة</span><span class="value">{c['address']['city']}</span></div>
</div>'''
                # Show documents
                db = st.session_state.db
                docs = db.get_citizen_documents_status(c["id_number"])
                if docs:
                    html += '<div class="card"><h4>📄 المستندات</h4>'
                    for d in docs:
                        cls = {"valid":"ok","expired":"bad","expiring_soon":"warn"}.get(d.status,"")
                        txt = {"valid":"ساري","expired":"منتهي","expiring_soon":"قارب"}.get(d.status,"")
                        html += f'<div class="doc"><span class="name">{d.name}</span><span class="badge {cls}">{txt}</span></div>'
                    html += '</div>'
                if exp:
                    html += f'<div class="card warning"><h4>⚠️ مستندات منتهية</h4><p>{", ".join(exp)}</p></div>'
            else:
                html += f'<div class="card error"><h4>❌</h4><p>{result["error"]}</p></div>'
        
        elif func_name == "renewal":
            if result["success"]:
                html += f'<div class="card info"><h4>📸 مطلوب صورة المستند</h4><p>{result["message"]}</p></div>'
            else:
                html += f'<div class="card warning"><h4>⚠️</h4><p>{result["error"]}</p></div>'
        
        elif func_name == "complete_renewal":
            if result["success"]:
                html += f'''<div class="card success">
<h4>✅ تم التجديد بنجاح</h4>
<p>رقم الطلب: {result["request_id"]}</p>
<p>تاريخ الانتهاء الجديد: {result["new_expiry"]}</p>
</div>'''
            else:
                html += f'<div class="card error"><h4>❌</h4><p>{result["error"]}</p></div>'
        
        elif func_name == "wakala":
            if "warning" in result:
                html += f'''<div class="card error">
<h4>⛔ تحذير: وكالة عامة</h4>
<p>{result["warning"]}</p>
<p><b>النصيحة:</b> {result["recommendation"]}</p>
</div>'''
            elif "template" in result:
                html += f'''<div class="card success">
<h4>✅ وكالة خاصة لـ {result["purpose"]}</h4>
<p>مستوى الخطر: {result["risk"]}</p>
</div>
<div class="card">
<h4>📝 نموذج الوكالة</h4>
<p style="white-space: pre-wrap; font-size: 11px;">{result["template"]}</p>
</div>
<div class="card warning">
<h4>⚠️ نصائح</h4>
<p>• {"</p><p>• ".join(result["tips"])}</p>
</div>'''
            elif "types" in result:
                html += '<div class="card info"><h4>📋 أنواع الوكالات</h4>'
                for t in result["types"]:
                    emoji = "✅" if t["risk"] == "منخفض" else "⛔"
                    html += f'<p><b>{emoji} {t["name"]}</b> - {t["description"]}</p>'
                html += f'<p><b>السؤال:</b> {result["recommendation"]}</p></div>'
        
        elif func_name == "services":
            html += '<div class="card info"><h4>🔷 الخدمات المتاحة</h4>'
            for s in result["services"]:
                html += f'<p>• {s}</p>'
            html += '</div>'
    
    return html

# ===================== MAIN PROCESS =====================
def process(user_text: str, has_image: bool = False) -> str:
    """Main processing function - LLM first"""
    
    # If pending renewal and has image, complete it
    if has_image and st.session_state.pending_action:
        if st.session_state.pending_action["type"] == "renewal":
            result = fn_complete_renewal()
            if result["success"]:
                return f'''تم استلام الصورة ✓

<div class="card success">
<h4>✅ تم التجديد بنجاح</h4>
<p>رقم الطلب: {result["request_id"]}</p>
<p>تاريخ الانتهاء الجديد: {result["new_expiry"]}</p>
</div>

هل تحتاج شيء آخر؟'''
    
    # Call LLM
    llm_response = call_llm(user_text, has_image)
    
    if llm_response.startswith("ERROR:"):
        return '<div class="card error"><h4>⚠️</h4><p>تأكد من تشغيل Ollama</p></div>'
    
    # Execute functions
    clean_text, results = execute_functions(llm_response)
    
    # Filter Arabic
    clean_text = filter_non_arabic(clean_text)
    
    # Render results
    results_html = render_results(results)
    
    # Combine
    if results_html:
        return f"{clean_text}<br><br>{results_html}" if clean_text else results_html
    
    return clean_text if clean_text else "كيف أقدر أساعدك؟"

def filter_non_arabic(text: str) -> str:
    """Remove non-Arabic content"""
    if not text:
        return ""
    
    lines = text.split('\n')
    filtered = []
    
    for line in lines:
        if not line.strip():
            continue
        # Skip lines with Chinese/Japanese/Korean
        if any('\u4e00' <= c <= '\u9fff' or '\u3040' <= c <= '\u30ff' for c in line):
            continue
        # Skip garbage
        if any(w in line.lower() for w in ['```', 'error', 'exception']):
            continue
        filtered.append(line)
    
    return '\n'.join(filtered).strip()

# ===================== UI =====================

# Header
st.markdown('''
<div class="header">
    <div class="logo">🔷</div>
    <h1>مساعد أبشر</h1>
    <p>خدماتك الحكومية بالذكاء الاصطناعي</p>
</div>
''', unsafe_allow_html=True)

# Chat
st.markdown('<div class="chat-box">', unsafe_allow_html=True)

if not st.session_state.msgs:
    st.markdown('''
<div class="msg bot">
    <div class="av">🔷</div>
    <div class="bub">
        أهلاً بك! 👋<br><br>
        أقدر أساعدك في تجديد الهوية، الجواز، الرخصة، أو الاستمارة.<br>
        وأقدر أنصحك في الوكالات الشرعية.<br><br>
        أدخل رقم هويتك أو اكتب طلبك 🔢
    </div>
</div>
''', unsafe_allow_html=True)

for m in st.session_state.msgs:
    cls = "user" if m["r"] == "user" else "bot"
    av = "👤" if m["r"] == "user" else "🔷"
    st.markdown(f'''
<div class="msg {cls}">
    <div class="av">{av}</div>
    <div class="bub">{m["c"]}</div>
</div>''', unsafe_allow_html=True)

st.markdown('</div>', unsafe_allow_html=True)

# Input
st.markdown('<div class="input-area">', unsafe_allow_html=True)

uploaded = st.file_uploader("📎 رفع صورة المستند", type=['png','jpg','jpeg'], key="upload")
if uploaded:
    st.image(uploaded, width=150)
    st.success(f"✓ {uploaded.name}")

with st.form("chat_form", clear_on_submit=True):
    col1, col2 = st.columns([5, 1])
    with col1:
        user_text = st.text_input("msg", placeholder="اكتب رسالتك هنا...", label_visibility="collapsed")
    with col2:
        submitted = st.form_submit_button("إرسال")

if submitted and user_text:
    has_img = uploaded is not None
    display_msg = f"📎 {uploaded.name}<br>{user_text}" if has_img else user_text
    
    st.session_state.msgs.append({"r": "user", "c": display_msg})
    response = process(user_text, has_img)
    st.session_state.msgs.append({"r": "bot", "c": response})
    st.rerun()

st.markdown('</div>', unsafe_allow_html=True)

# Reset
col1, col2, col3 = st.columns([1, 1, 1])
with col2:
    if st.button("🔄 محادثة جديدة"):
        st.session_state.msgs = []
        st.session_state.citizen = None
        st.session_state.pending_action = None
        st.rerun()