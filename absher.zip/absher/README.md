# RAG Infrastructure - أبشر الذكي
## Module 2: مهندس بيانات واسترجاع

<div dir="rtl">

### نظرة عامة
نظام RAG للبنية التحتية يدعم:
- تجهيز البيانات وتقسيمها (Data Ingestion)
- قاعدة بيانات متجهة (Vector DB)
- استخراج النصوص من المستندات (OCR)
- تحويل الصوت لنص للهجات السعودية (STT)
- مستشار الوكالات الذكي

</div>

---

## 🖥️ Hardware Requirements

**Optimized for RTX 5070 Ti (16GB VRAM)**

| Model | Size | Purpose |
|-------|------|---------|
| qwen2.5:14b | 8.9GB | LLM (Best for Arabic) |
| nomic-embed-text | 274MB | Embeddings |
| llama3.2-vision | 2.0GB | Vision/OCR |

---

## 🚀 Quick Start

### 1. Install Ollama
```bash
curl -fsSL https://ollama.ai/install.sh | sh
```

### 2. Setup Models
```bash
chmod +x setup_ollama.sh
./setup_ollama.sh
```

### 3. Install Python Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run Tests
```bash
python tests.py
```

---

## 📁 Project Structure

```
rag-absher/
├── ollama_client.py      # Ollama API Client
├── knowledge_base.py     # Absher Services Data
├── schemas.py            # JSON Schemas for Module 3
├── vector_db.py          # Vector Database
├── ocr_system.py         # Document OCR
├── speech_to_text.py     # Speech-to-Text
├── wakala_advisor.py     # Wakala Risk Analyzer
├── rag_system.py         # Main System
├── tests.py              # Comprehensive Tests
├── setup_ollama.sh       # Ollama Setup Script
└── requirements.txt      # Python Dependencies
```

---

## 📋 Integration Schema (Module 3)

### Input Processing Output
```json
{
  "input_id": "INP-xxx",
  "input_type": "صوت",
  "processed_text": "أبغى أجدد جواز السفر",
  "intent": "تجديد",
  "service_category": "الجوازات",
  "service_name": "تجديد جواز السفر",
  "entities": {"document_type": "جواز_سفر"},
  "confidence": 0.95,
  "dialect": "najdi"
}
```

### Document Extraction Output
```json
{
  "document_id": "DOC-xxx",
  "document_type": "هوية_وطنية",
  "fields": {
    "id_number": "1234567890",
    "name_ar": "محمد أحمد",
    "expiry_date": "2027/05/15"
  },
  "confidence": 0.92,
  "is_valid": true,
  "is_expired": false
}
```

### Full Integration Output
```json
{
  "request_id": "REQ-xxx",
  "service": {
    "detected": "تجديد جواز السفر",
    "category": "الجوازات",
    "intent": "تجديد"
  },
  "requirements": {
    "status": {"هوية_وطنية": true, "صورة_شخصية": false},
    "missing": ["صورة_شخصية"],
    "completion": 50.0
  },
  "risk_analysis": {
    "level": "منخفض",
    "warnings_count": 0
  },
  "ready_for_submission": false
}
```

---

## 🧪 Test Results

```
✓ Ollama Client      - Connection & Models
✓ Knowledge Base     - 10 Services, 5 FAQ
✓ Data Ingestion     - Chunking & Cleaning
✓ Speech-to-Text     - 100% Dialect Detection
✓ OCR System         - Document Extraction
✓ Wakala Advisor     - Risk Detection
✓ Integration Schema - JSON Output
✓ Full Pipeline      - End-to-End

Overall: 8/8 (100%)
```

---

## 🔧 Usage

### Basic Usage
```python
from rag_system import create_rag_system

# Initialize
rag = create_rag_system()

# Process text
result = rag.process_request(text="أبغى أجدد جواز السفر")
print(result.summary())

# Analyze wakala
analysis = rag.analyze_wakala("وكالة عامة بدون قيود")
print(analysis)
```

### With Documents
```python
from schemas import DocumentType

result = rag.process_request(
    text="أبغى أجدد جواز السفر",
    documents=[
        (image_base64, DocumentType.NATIONAL_ID),
        (photo_base64, DocumentType.PHOTO)
    ]
)

print(f"Completion: {result.completion_percentage}%")
print(f"Missing: {result.missing_documents}")
```

---

## 📜 Wakala Advisor

### Dangerous Terms Detection
- ❌ التنازل عن كافة الحقوق
- ❌ بدون قيود
- ❌ تفويض مطلق
- ⚠️ لأي وقت مستقبلي
- ⚠️ كافة التصرفات

### Safe Alternative Suggestions
```python
safe_wakala = rag.suggest_safe_wakala("بيع عقار")
print(safe_wakala)
```

---

## 🌐 Dialect Support

| Dialect | Keywords |
|---------|----------|
| Najdi (نجدي) | وش، ليش، اللحين، أبغى |
| Hijazi (حجازي) | إيش، كدا، دحين، عايز |
| Eastern (شرقي) | شلون، هيج، آني، ماكو |
| Standard | ماذا، أريد، كيف |

---

<div dir="rtl">

## 📞 نقطة التكامل مع Module 3

يجب الاتفاق على:
1. **UserInput** - مدخلات المستخدم المعالجة
2. **ExtractedDocument** - المستندات المستخرجة
3. **IntegrationOutput** - الخرج الكامل للطلب

كل هذه الـ Schemas موثقة في `schemas.py`

</div>
