"""
قاعدة معرفة أبشر الشاملة
Absher Knowledge Base
"""

# === الجوازات ===
PASSPORT_SERVICES = {
    "passport_renewal": {
        "name": "تجديد جواز السفر",
        "category": "الجوازات",
        "description": "تجديد جواز السفر السعودي إلكترونياً عبر أبشر",
        "conditions": [
            "الجواز منتهي أو ينتهي خلال 6 أشهر",
            "الهوية الوطنية سارية",
            "لا يوجد قيود سفر",
            "البصمة محدثة (آخر 5 سنوات)"
        ],
        "requirements": ["صورة شخصية 4×6 خلفية بيضاء", "الهوية الوطنية سارية"],
        "steps": ["الدخول على أبشر", "خدماتي > الجوازات", "تجديد جواز السفر", "رفع الصورة", "سداد الرسوم"],
        "fees": "300 ريال (5 سنوات) / 500 ريال (10 سنوات)",
        "duration": "3-5 أيام عمل",
        "documents": ["صورة_شخصية", "هوية_وطنية"]
    },
    "passport_new": {
        "name": "إصدار جواز جديد",
        "category": "الجوازات",
        "description": "إصدار جواز سفر لأول مرة",
        "conditions": ["سعودي الجنسية", "هوية وطنية سارية"],
        "requirements": ["الهوية الوطنية", "صورة شخصية", "موافقة ولي الأمر (للقاصرين)"],
        "fees": "300-500 ريال",
        "duration": "5-7 أيام",
        "documents": ["هوية_وطنية", "صورة_شخصية"]
    },
    "passport_lost": {
        "name": "جواز بدل فاقد",
        "category": "الجوازات",
        "description": "إصدار جواز بدل فاقد",
        "requirements": ["بلاغ فقدان", "الهوية الوطنية", "صورة شخصية"],
        "fees": "500 ريال (أول مرة) / 1000 ريال (ثاني مرة)",
        "duration": "7-10 أيام",
        "documents": ["بلاغ_فقدان", "هوية_وطنية", "صورة_شخصية"]
    }
}

# === الأحوال المدنية ===
CIVIL_SERVICES = {
    "id_renewal": {
        "name": "تجديد الهوية الوطنية",
        "category": "الأحوال المدنية",
        "description": "تجديد بطاقة الهوية الوطنية",
        "conditions": ["الهوية منتهية أو تنتهي خلال 180 يوم"],
        "requirements": ["الهوية القديمة", "صورة شخصية", "إثبات العنوان"],
        "fees": "مجاناً / 100 ريال (بدل فاقد)",
        "duration": "فوري",
        "documents": ["هوية_وطنية"]
    },
    "birth_registration": {
        "name": "تسجيل مولود",
        "category": "الأحوال المدنية",
        "description": "تسجيل مولود جديد",
        "conditions": ["التسجيل خلال 15 يوماً", "الأب سعودي", "عقد زواج موثق"],
        "requirements": ["شهادة الولادة", "هوية الأب", "هوية الأم", "عقد الزواج"],
        "fees": "مجاناً",
        "duration": "1-3 أيام",
        "documents": ["شهادة_ميلاد", "هوية_وطنية", "عقد_زواج"]
    }
}

# === المرور ===
TRAFFIC_SERVICES = {
    "license_renewal": {
        "name": "تجديد رخصة القيادة",
        "category": "المرور",
        "description": "تجديد رخصة القيادة إلكترونياً",
        "conditions": ["الرخصة منتهية أو تنتهي خلال 90 يوم", "سداد المخالفات"],
        "requirements": ["الهوية الوطنية", "سداد المخالفات", "فحص طبي (فوق 60 سنة)"],
        "fees": "40 ريال/سنة - 400 ريال/10 سنوات",
        "duration": "فوري",
        "documents": ["هوية_وطنية"]
    },
    "vehicle_renewal": {
        "name": "تجديد استمارة المركبة",
        "category": "المرور",
        "description": "تجديد رخصة سير المركبة",
        "conditions": ["تأمين ساري", "فحص دوري ساري", "سداد المخالفات"],
        "requirements": ["تأمين ساري", "فحص دوري ساري"],
        "fees": "100-300 ريال",
        "duration": "فوري",
        "documents": ["وثيقة_تأمين", "شهادة_فحص"]
    }
}

# === التأشيرات ===
VISA_SERVICES = {
    "family_visit": {
        "name": "تأشيرة زيارة عائلية",
        "category": "التأشيرات",
        "description": "إصدار تأشيرة لزيارة الأقارب",
        "conditions": ["إقامة سارية 6 أشهر", "مضى سنة على الإقامة", "راتب 5000+", "قرابة درجة أولى"],
        "requirements": ["إقامة سارية", "خطاب تعريف", "كشف حساب", "إثبات القرابة"],
        "fees": "300-2000 ريال",
        "duration": "3-7 أيام",
        "documents": ["إقامة", "كشف_حساب"]
    },
    "exit_reentry": {
        "name": "تأشيرة خروج وعودة",
        "category": "التأشيرات",
        "description": "إصدار تأشيرة خروج وعودة للمقيمين",
        "conditions": ["إقامة سارية", "موافقة الكفيل"],
        "requirements": ["الإقامة"],
        "fees": "200-500 ريال",
        "duration": "فوري",
        "documents": ["إقامة"]
    }
}

# === الوكالات ===
WAKALA_INFO = {
    "types": {
        "عامة": {"risk": "حرج", "desc": "صلاحيات شاملة - خطيرة جداً"},
        "خاصة": {"risk": "منخفض", "desc": "محددة لتصرف معين - آمنة"},
        "بيع عقار": {"risk": "متوسط", "desc": "لبيع عقار محدد"},
        "استلام": {"risk": "منخفض", "desc": "لاستلام مستندات أو أموال"}
    },
    "dangerous_terms": [
        {"term": "التنازل عن كافة الحقوق", "risk": "حرج", "warning": "تسمح بالتنازل عن أي حق"},
        {"term": "بدون قيود", "risk": "حرج", "warning": "تزيل كل الحماية القانونية"},
        {"term": "تفويض مطلق", "risk": "حرج", "warning": "صلاحيات غير محدودة"},
        {"term": "لأي وقت مستقبلي", "risk": "مرتفع", "warning": "وكالة مفتوحة بلا نهاية"},
        {"term": "كافة التصرفات", "risk": "مرتفع", "warning": "تشمل البيع والرهن والهبة"},
        {"term": "نيابة كاملة", "risk": "مرتفع", "warning": "تمثيل كامل في كل شيء"}
    ]
}

# === الأسئلة الشائعة ===
FAQ = [
    {"q": "ما الفرق بين تجديد الجواز وإصدار جديد؟", "a": "التجديد للمنتهي بنفس الرقم. الإصدار لأول مرة أو بدل فاقد برقم جديد.", "cat": "الجوازات"},
    {"q": "هل يمكن السفر بجواز منتهي؟", "a": "لا، يجب التجديد أولاً. بعض الدول تشترط صلاحية 6 أشهر.", "cat": "الجوازات"},
    {"q": "كم مدة صلاحية الفحص الدوري؟", "a": "سنتان للجديدة، سنة للقديمة، 6 أشهر للثقيلة.", "cat": "المرور"},
    {"q": "ما غرامة تأخير تجديد الهوية؟", "a": "100 ريال بعد 180 يوم من الانتهاء.", "cat": "الأحوال المدنية"},
    {"q": "ما الفرق بين الوكالة العامة والخاصة؟", "a": "العامة صلاحيات شاملة (خطيرة). الخاصة محددة (آمنة). يُنصح بالخاصة دائماً.", "cat": "الوكالات"}
]


def get_all_services():
    """كل الخدمات"""
    all_svcs = {}
    all_svcs.update(PASSPORT_SERVICES)
    all_svcs.update(CIVIL_SERVICES)
    all_svcs.update(TRAFFIC_SERVICES)
    all_svcs.update(VISA_SERVICES)
    return all_svcs


def get_service(service_id: str):
    """خدمة بالـ ID"""
    return get_all_services().get(service_id)


def get_by_category(category: str):
    """خدمات حسب الفئة"""
    return [s for s in get_all_services().values() if s["category"] == category]


def get_indexable_content():
    """محتوى للفهرسة"""
    content = []
    
    for sid, svc in get_all_services().items():
        text = f"""
{svc['name']}
الوصف: {svc['description']}
الشروط: {' | '.join(svc.get('conditions', []))}
المتطلبات: {' | '.join(svc['requirements'])}
الرسوم: {svc['fees']}
المدة: {svc['duration']}
"""
        content.append({
            "id": sid,
            "title": svc['name'],
            "category": svc['category'],
            "content": text,
            "documents": svc.get('documents', [])
        })
    
    # FAQ
    for i, f in enumerate(FAQ):
        content.append({
            "id": f"faq_{i}",
            "title": f["q"],
            "category": f["cat"],
            "content": f"س: {f['q']}\nج: {f['a']}"
        })
    
    return content


if __name__ == "__main__":
    services = get_all_services()
    print(f"📚 Services: {len(services)}")
    print(f"❓ FAQ: {len(FAQ)}")
    print(f"📄 Indexable: {len(get_indexable_content())}")
