"""
RAG System - النظام الرئيسي
============================
يدمج جميع المكونات:
1. Ollama Client (LLM + Embeddings + Vision)
2. Vector Database
3. OCR System
4. Speech-to-Text
5. Wakala Advisor
6. Integration Output for Module 3
"""

import hashlib
from datetime import datetime
from typing import List, Dict, Tuple, Optional

from ollama_client import OllamaClient, OllamaConfig
from knowledge_base import get_indexable_content, get_all_services, WAKALA_INFO
from schemas import (
    DocumentType, InputType, RiskLevel,
    ExtractedDocument, UserInput, RiskWarning,
    RetrievalResult, IntegrationOutput, generate_id
)
from vector_db import VectorDB, DataIngestion
from ocr_system import OCRSystem, MockOCR
from speech_to_text import SpeechToText
from wakala_advisor import WakalaAdvisor


class RAGSystem:
    """النظام الرئيسي للـ RAG"""
    
    def __init__(self, config: OllamaConfig = None, use_mock: bool = False):
        """
        تهيئة النظام
        
        Args:
            config: إعدادات Ollama
            use_mock: استخدام Mock للاختبار بدون Ollama
        """
        self.config = config or OllamaConfig()
        self.use_mock = use_mock
        
        # Ollama Client
        self.ollama = OllamaClient(self.config)
        
        # التحقق من الاتصال
        self.ollama_available = self.ollama.is_available()
        if not self.ollama_available:
            print("⚠ Ollama not available - using mock mode")
            self.use_mock = True
        
        # المكونات
        self.ingestion = DataIngestion(chunk_size=500, overlap=50)
        self.db = VectorDB(self.ollama) if not self.use_mock else None
        self.ocr = OCRSystem(self.ollama) if not self.use_mock else MockOCR()
        self.stt = SpeechToText()
        self.wakala = WakalaAdvisor()
        
        # الحالة
        self.initialized = False
        self.indexed_count = 0
    
    def initialize(self) -> bool:
        """تهيئة النظام وفهرسة قاعدة المعرفة"""
        print("\n📚 Initializing RAG System...")
        
        if self.use_mock:
            print("   ⚠ Running in mock mode")
            self.initialized = True
            return True
        
        # الحصول على المحتوى
        content = get_indexable_content()
        print(f"   📄 Content items: {len(content)}")
        
        # المعالجة والفهرسة
        processed = self.ingestion.process_content(content)
        print(f"   📝 Processed chunks: {len(processed)}")
        
        # الفهرسة
        self.indexed_count = self.db.add_batch(processed)
        print(f"   ✓ Indexed: {self.indexed_count} chunks")
        
        self.initialized = True
        return True
    
    # === معالجة المدخلات ===
    
    def process_text(self, text: str) -> UserInput:
        """معالجة نص"""
        return self.stt.process_text(text)
    
    def process_voice(self, audio_b64: str) -> UserInput:
        """معالجة صوت"""
        return self.stt.transcribe(audio_b64)
    
    def process_document(self, image_b64: str, doc_type: DocumentType = None) -> ExtractedDocument:
        """معالجة مستند"""
        return self.ocr.extract(image_b64, doc_type)
    
    # === البحث ===
    
    def search(self, query: str, k: int = 5) -> List[RetrievalResult]:
        """بحث في قاعدة المعرفة"""
        if self.use_mock or not self.db:
            return []
        return self.db.search(query, k)
    
    def answer(self, question: str) -> str:
        """الإجابة على سؤال"""
        if self.use_mock:
            return "هذا رد تجريبي - شغّل Ollama للحصول على إجابات حقيقية"
        
        # البحث
        results = self.search(question, k=3)
        if not results:
            return "لم أجد معلومات كافية للإجابة على سؤالك."
        
        # بناء السياق
        context = "\n\n".join([f"[{r.category}]: {r.content}" for r in results])
        
        # التوليد
        prompt = f"""أنت مساعد أبشر. أجب على السؤال بناءً على السياق.

السياق:
{context}

السؤال: {question}

أجب بالعربية بشكل مختصر ودقيق."""
        
        return self.ollama.arabic(prompt)
    
    # === تحليل الوكالات ===
    
    def analyze_wakala(self, wakala_text: str) -> Dict:
        """تحليل وكالة"""
        analysis = self.wakala.analyze(wakala_text)
        return analysis.to_dict()
    
    def suggest_safe_wakala(self, purpose: str) -> str:
        """اقتراح وكالة آمنة"""
        return self.wakala.suggest_safe_wakala(purpose)
    
    # === التحقق من المتطلبات ===
    
    def check_requirements(self, service_id: str, documents: List[ExtractedDocument]) -> Dict[str, bool]:
        """التحقق من متطلبات الخدمة"""
        services = get_all_services()
        service = services.get(service_id, {})
        required_docs = service.get("documents", [])
        
        # تحويل أنواع المستندات المرفوعة
        uploaded_types = {doc.document_type.value for doc in documents if doc.is_valid}
        
        status = {}
        for req in required_docs:
            status[req] = req in uploaded_types
        
        return status
    
    def get_missing_documents(self, service_id: str, documents: List[ExtractedDocument]) -> List[str]:
        """الحصول على المستندات الناقصة"""
        status = self.check_requirements(service_id, documents)
        return [doc for doc, present in status.items() if not present]
    
    # === المعالجة الكاملة ===
    
    def process_request(
        self,
        text: str = None,
        voice_b64: str = None,
        documents: List[Tuple[str, DocumentType]] = None
    ) -> IntegrationOutput:
        """
        معالجة طلب كامل - الخرج الرئيسي لـ Module 3
        
        Args:
            text: نص الطلب
            voice_b64: صوت بـ Base64
            documents: قائمة (صورة, نوع المستند)
        
        Returns:
            IntegrationOutput جاهز للـ Module 3
        """
        request_id = generate_id("REQ")
        
        # 1. معالجة المدخل
        if voice_b64:
            user_input = self.process_voice(voice_b64)
        elif text:
            user_input = self.process_text(text)
        else:
            raise ValueError("يجب توفير نص أو صوت")
        
        # 2. معالجة المستندات
        extracted_docs = []
        if documents:
            for img_b64, doc_type in documents:
                doc = self.process_document(img_b64, doc_type)
                extracted_docs.append(doc)
        
        # 3. البحث في قاعدة المعرفة
        context = self.search(user_input.processed_text, k=5)
        
        # 4. تحديد الخدمة
        service_name = user_input.service_name
        service_category = user_input.service_category
        intent = user_input.intent
        
        # 5. التحقق من المتطلبات
        # البحث عن service_id من الاسم
        services = get_all_services()
        service_id = None
        for sid, svc in services.items():
            if svc["name"] == service_name or service_name in svc["name"]:
                service_id = sid
                break
        
        if service_id:
            requirements = self.check_requirements(service_id, extracted_docs)
            missing = self.get_missing_documents(service_id, extracted_docs)
        else:
            requirements = {}
            missing = []
        
        # حساب نسبة الاكتمال
        if requirements:
            completed = sum(1 for v in requirements.values() if v)
            completion = (completed / len(requirements)) * 100
        else:
            completion = 0.0
        
        # 6. تحليل المخاطر
        risk_warnings = []
        risk_level = RiskLevel.LOW
        
        # تحليل الوكالات
        if service_category == "الوكالات" or "وكالة" in user_input.processed_text:
            wakala_analysis = self.wakala.analyze(user_input.processed_text)
            risk_warnings = wakala_analysis.warnings
            risk_level = wakala_analysis.risk_level
        
        # التحقق من صلاحية المستندات
        for doc in extracted_docs:
            if doc.is_expired:
                risk_warnings.append(RiskWarning(
                    term=f"مستند منتهي: {doc.document_type.value}",
                    level=RiskLevel.HIGH,
                    warning=f"المستند {doc.document_type.value} منتهي الصلاحية",
                    recommendation="يرجى تجديد المستند"
                ))
                if risk_level == RiskLevel.LOW:
                    risk_level = RiskLevel.MEDIUM
        
        # 7. التوصيات
        recommendations = []
        if missing:
            recommendations.append(f"المستندات الناقصة: {', '.join(missing)}")
        if completion < 100:
            recommendations.append(f"نسبة الاكتمال: {completion:.0f}%")
        if risk_warnings:
            recommendations.append("راجع التحذيرات قبل المتابعة")
        if completion >= 100 and risk_level == RiskLevel.LOW:
            recommendations.append("✅ الطلب جاهز للتقديم")
        
        return IntegrationOutput(
            request_id=request_id,
            user_input=user_input,
            documents=extracted_docs,
            retrieved_context=context,
            service_detected=service_name,
            service_category=service_category,
            intent=intent,
            requirements=requirements,
            missing_documents=missing,
            completion_percentage=completion,
            risk_warnings=risk_warnings,
            risk_level=risk_level,
            recommendations=recommendations
        )
    
    # === الإحصائيات ===
    
    def stats(self) -> Dict:
        """إحصائيات النظام"""
        return {
            "initialized": self.initialized,
            "ollama_available": self.ollama_available,
            "mock_mode": self.use_mock,
            "indexed_chunks": self.indexed_count,
            "vector_db": self.db.stats() if self.db else None,
            "whisper_available": self.stt.whisper_available,
            "config": {
                "llm_model": self.config.llm_model,
                "embed_model": self.config.embed_model,
                "vision_model": self.config.vision_model
            }
        }


# === Factory ===

def create_rag_system(use_mock: bool = False) -> RAGSystem:
    """إنشاء نظام RAG"""
    config = OllamaConfig()
    system = RAGSystem(config, use_mock)
    system.initialize()
    return system


if __name__ == "__main__":
    print("=" * 60)
    print("🔷 RAG System - Absher Smart Assistant")
    print("=" * 60)
    
    # إنشاء النظام (mock mode للاختبار)
    rag = create_rag_system(use_mock=True)
    
    print(f"\n📊 Stats: {rag.stats()}")
    
    # اختبار معالجة نص
    print("\n" + "=" * 60)
    print("📝 Test: Text Processing")
    print("=" * 60)
    
    result = rag.process_request(text="أبغى أجدد جواز السفر")
    
    print(result.summary())
    
    # اختبار تحليل وكالة
    print("\n" + "=" * 60)
    print("📜 Test: Wakala Analysis")
    print("=" * 60)
    
    wakala_text = "وكالة عامة بدون قيود مع التنازل عن كافة الحقوق"
    analysis = rag.analyze_wakala(wakala_text)
    
    print(f"   Risk: {analysis['risk_level']}")
    print(f"   Warnings: {analysis['warnings_count']}")
    print(f"   Safe Alternative: {analysis['safe_alternative']}")
