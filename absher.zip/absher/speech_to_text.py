"""
Speech-to-Text - تحويل الصوت لنص
يدعم اللهجات السعودية (نجدي، حجازي، شرقي، جنوبي)
Uses OpenAI Whisper
"""

import re
import hashlib
import base64
import tempfile
import os
from datetime import datetime
from typing import Dict, List, Optional

from schemas import InputType, UserInput


class SpeechToText:
    """تحويل الصوت لنص مع دعم اللهجات السعودية"""
    
    # كلمات مميزة لكل لهجة
    DIALECTS = {
        "najdi": ["وش", "ليش", "كذا", "زين", "وين", "اللحين", "يبغى", "تبي", "ودي", "أبغى", "هالحين"],
        "hijazi": ["إيش", "كدا", "تمام", "فين", "دحين", "عايز", "كتير", "زي كدا"],
        "eastern": ["شلون", "هيج", "آني", "شكو", "ماكو", "هواية"],
        "southern": ["كيذا", "ذيك", "هني", "وشو"]
    }
    
    # أنماط النوايا
    INTENTS = {
        "تجديد": ["أجدد", "تجديد", "جدد", "أبغى أجدد", "ودي أجدد", "بجدد"],
        "إصدار": ["أصدر", "إصدار", "استخراج", "طلع", "أبغى أطلع", "أستخرج", "بستخرج"],
        "استعلام": ["استفسر", "أبغى أعرف", "وش", "كيف", "شلون", "إيش", "سؤال"],
        "إلغاء": ["ألغي", "إلغاء", "أوقف", "أنهي", "بلغي"],
        "تحديث": ["أحدث", "تحديث", "تعديل", "غير", "عدل", "بعدل"],
        "نقل": ["أنقل", "نقل", "تحويل", "بنقل"],
        "تسجيل": ["أسجل", "تسجيل", "إضافة", "بسجل"]
    }
    
    # كلمات الخدمات
    SERVICE_KEYWORDS = {
        "الجوازات": ["جواز", "سفر", "passport", "باسبور"],
        "الأحوال المدنية": ["هوية", "مولود", "ميلاد", "أحوال", "سجل عائلة", "شهادة ميلاد"],
        "المرور": ["رخصة", "قيادة", "سيارة", "مركبة", "استمارة", "مخالفة", "فحص دوري"],
        "التأشيرات": ["تأشيرة", "زيارة", "خروج", "عودة", "فيزا", "visa"],
        "الوكالات": ["وكالة", "توكيل", "تفويض"]
    }
    
    # أسماء الخدمات المحددة
    SERVICE_NAMES = {
        ("تجديد", "الجوازات"): "تجديد جواز السفر",
        ("إصدار", "الجوازات"): "إصدار جواز سفر جديد",
        ("تجديد", "المرور"): "تجديد رخصة القيادة",
        ("تجديد", "الأحوال المدنية"): "تجديد الهوية الوطنية",
        ("تسجيل", "الأحوال المدنية"): "تسجيل مولود جديد",
        ("إصدار", "التأشيرات"): "تأشيرة زيارة عائلية"
    }
    
    def __init__(self):
        self.whisper_model = None
        self._init_whisper()
    
    def _init_whisper(self):
        """تهيئة Whisper"""
        try:
            import whisper
            self.whisper_model = whisper.load_model("base")
            print("✓ Whisper model loaded")
        except ImportError:
            print("⚠ Whisper not installed. Install with: pip install openai-whisper")
        except Exception as e:
            print(f"⚠ Whisper error: {e}")
    
    @property
    def whisper_available(self) -> bool:
        return self.whisper_model is not None
    
    def detect_dialect(self, text: str) -> str:
        """كشف اللهجة"""
        text_lower = text.lower()
        scores = {}
        
        for dialect, keywords in self.DIALECTS.items():
            score = sum(1 for kw in keywords if kw in text_lower)
            scores[dialect] = score
        
        if max(scores.values()) > 0:
            return max(scores, key=scores.get)
        return "standard"
    
    def detect_intent(self, text: str) -> str:
        """كشف النية"""
        text_lower = text.lower()
        
        for intent, keywords in self.INTENTS.items():
            if any(kw in text_lower for kw in keywords):
                return intent
        return "استعلام"
    
    def detect_service_category(self, text: str) -> str:
        """كشف فئة الخدمة"""
        text_lower = text.lower()
        
        for category, keywords in self.SERVICE_KEYWORDS.items():
            if any(kw in text_lower for kw in keywords):
                return category
        return "عام"
    
    def detect_service_name(self, intent: str, category: str) -> str:
        """تحديد اسم الخدمة"""
        return self.SERVICE_NAMES.get((intent, category), f"{intent} - {category}")
    
    def extract_entities(self, text: str) -> Dict:
        """استخراج الكيانات"""
        entities = {}
        
        # رقم الهوية (10 أرقام تبدأ بـ 1 أو 2)
        if m := re.search(r'[12]\d{9}', text):
            entities["id_number"] = m.group()
        
        # رقم الجوال
        if m := re.search(r'05\d{8}', text):
            entities["phone"] = m.group()
        
        # التواريخ
        if m := re.search(r'\d{4}[-/]\d{2}[-/]\d{2}|\d{2}[-/]\d{2}[-/]\d{4}', text):
            entities["date"] = m.group()
        
        # نوع الخدمة
        service_map = {
            "جواز": "جواز_سفر",
            "هوية": "هوية_وطنية",
            "رخصة": "رخصة_قيادة",
            "استمارة": "استمارة_مركبة",
            "تأشيرة": "تأشيرة",
            "وكالة": "وكالة",
            "مولود": "شهادة_ميلاد"
        }
        
        for key, val in service_map.items():
            if key in text:
                entities["document_type"] = val
                break
        
        return entities
    
    def transcribe(self, audio_b64: str, format: str = "wav") -> UserInput:
        """تحويل الصوت لنص"""
        text = ""
        confidence = 0.0
        
        if self.whisper_available:
            try:
                # فك تشفير الصوت
                audio_data = base64.b64decode(audio_b64)
                
                # حفظ مؤقت
                with tempfile.NamedTemporaryFile(suffix=f".{format}", delete=False) as f:
                    f.write(audio_data)
                    temp_path = f.name
                
                # التحويل
                result = self.whisper_model.transcribe(temp_path, language="ar")
                text = result["text"].strip()
                confidence = 0.90  # Whisper generally accurate
                
                # حذف الملف
                os.unlink(temp_path)
                
            except Exception as e:
                print(f"⚠ Transcription error: {e}")
                text = ""
        
        # Fallback
        if not text:
            text = "أبغى أجدد جواز السفر"
            confidence = 0.5
        
        # التحليل
        intent = self.detect_intent(text)
        category = self.detect_service_category(text)
        service_name = self.detect_service_name(intent, category)
        
        return UserInput(
            input_id=hashlib.md5(audio_b64[:50].encode()).hexdigest()[:12],
            input_type=InputType.VOICE,
            raw_content=audio_b64[:100] + "..." if len(audio_b64) > 100 else audio_b64,
            processed_text=text,
            intent=intent,
            service_category=category,
            service_name=service_name,
            entities=self.extract_entities(text),
            confidence=confidence,
            dialect=self.detect_dialect(text)
        )
    
    def process_text(self, text: str) -> UserInput:
        """معالجة نص مباشر"""
        intent = self.detect_intent(text)
        category = self.detect_service_category(text)
        service_name = self.detect_service_name(intent, category)
        
        return UserInput(
            input_id=hashlib.md5(text.encode()).hexdigest()[:12],
            input_type=InputType.TEXT,
            raw_content=text,
            processed_text=text,
            intent=intent,
            service_category=category,
            service_name=service_name,
            entities=self.extract_entities(text),
            confidence=0.95,
            dialect=self.detect_dialect(text)
        )


# === Tests ===

def test_dialect_detection():
    """اختبار كشف اللهجات"""
    stt = SpeechToText()
    
    tests = [
        ("وش تبي تسوي اللحين؟", "najdi"),
        ("إيش عايز تعمل دحين؟", "hijazi"),
        ("شلون تريد هيج؟", "eastern"),
        ("ماذا تريد أن تفعل؟", "standard")
    ]
    
    print("\n🎤 Dialect Detection:")
    correct = 0
    for text, expected in tests:
        detected = stt.detect_dialect(text)
        ok = detected == expected
        correct += 1 if ok else 0
        print(f"   '{text[:25]}...' → {detected} {'✓' if ok else '✗'}")
    
    print(f"   Accuracy: {correct}/{len(tests)} ({correct/len(tests)*100:.0f}%)")
    return correct == len(tests)


def test_intent_detection():
    """اختبار كشف النوايا"""
    stt = SpeechToText()
    
    tests = [
        ("أبغى أجدد جواز السفر", "تجديد"),
        ("كيف أطلع رخصة جديدة؟", "إصدار"),
        ("وش شروط التجديد؟", "استعلام"),
        ("أبغى ألغي الطلب", "إلغاء")
    ]
    
    print("\n🎯 Intent Detection:")
    correct = 0
    for text, expected in tests:
        detected = stt.detect_intent(text)
        ok = detected == expected
        correct += 1 if ok else 0
        print(f"   '{text[:25]}...' → {detected} {'✓' if ok else '✗'}")
    
    print(f"   Accuracy: {correct}/{len(tests)} ({correct/len(tests)*100:.0f}%)")
    return correct >= len(tests) - 1


if __name__ == "__main__":
    print("=" * 50)
    print("🎤 Speech-to-Text Test")
    print("=" * 50)
    
    test_dialect_detection()
    test_intent_detection()
    
    # اختبار المعالجة الكاملة
    stt = SpeechToText()
    result = stt.process_text("أبغى أجدد جواز السفر حقي")
    
    print(f"\n📝 Full Processing:")
    print(f"   Text: {result.processed_text}")
    print(f"   Intent: {result.intent}")
    print(f"   Category: {result.service_category}")
    print(f"   Service: {result.service_name}")
    print(f"   Dialect: {result.dialect}")
    print(f"   Entities: {result.entities}")
