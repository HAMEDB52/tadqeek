#!/usr/bin/env python3
"""
RAG Absher - Interactive Demo
نظام مساعد الخدمات الحكومية السعودية
"""

import sys
import base64
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from rag_system import create_rag_system
from wakala_advisor import WakalaAdvisor
from speech_to_text import SpeechToText

# Colors
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BLUE = "\033[94m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_header():
    print(f"""
{CYAN}╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║   {BOLD}🔷 RAG Absher - مساعد الخدمات الحكومية{RESET}{CYAN}                     ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝{RESET}
""")

def print_menu():
    print(f"""
{BOLD}الأوامر المتاحة:{RESET}
────────────────────────────────────────
  {GREEN}1{RESET} │ طلب خدمة (نص)         │ Process service request
  {GREEN}2{RESET} │ تحليل وكالة           │ Analyze wakala
  {GREEN}3{RESET} │ اقتراح وكالة آمنة     │ Suggest safe wakala
  {GREEN}4{RESET} │ البحث في قاعدة المعرفة │ Search knowledge base
  {GREEN}5{RESET} │ سؤال وجواب            │ Ask a question
  {GREEN}6{RESET} │ معالجة مستند (صورة)   │ Process document (image)
  {GREEN}7{RESET} │ إحصائيات النظام       │ System stats
────────────────────────────────────────
  {YELLOW}h{RESET} │ عرض القائمة           │ Show menu
  {RED}q{RESET} │ خروج                  │ Quit
────────────────────────────────────────
""")

def process_request(rag):
    """معالجة طلب خدمة"""
    print(f"\n{CYAN}═══ طلب خدمة ═══{RESET}")
    text = input(f"{BOLD}أدخل طلبك:{RESET} ").strip()
    
    if not text:
        print(f"{RED}لم يتم إدخال نص{RESET}")
        return
    
    print(f"\n{YELLOW}جاري المعالجة...{RESET}")
    result = rag.process_request(text=text)
    
    print(f"""
{GREEN}═══ النتيجة ═══{RESET}
  {BOLD}الخدمة:{RESET}     {result.service_detected or 'غير محددة'}
  {BOLD}التصنيف:{RESET}    {result.service_category or 'غير محدد'}
  {BOLD}النية:{RESET}      {result.intent or 'غير محددة'}
  {BOLD}الاكتمال:{RESET}   {result.completion_percentage:.0f}%
  {BOLD}المستوى:{RESET}    {result.risk_level}
  
  {BOLD}المستندات الناقصة:{RESET}
""")
    if result.missing_documents:
        for doc in result.missing_documents:
            print(f"    • {doc}")
    else:
        print(f"    {GREEN}✓ جميع المستندات مكتملة{RESET}")
    
    print(f"\n  {BOLD}جاهز للتقديم:{RESET} {'✓ نعم' if result.ready_for_submission else '✗ لا'}")

def analyze_wakala(advisor):
    """تحليل وكالة"""
    print(f"\n{CYAN}═══ تحليل وكالة ═══{RESET}")
    print(f"{BOLD}أدخل نص الوكالة (اضغط Enter مرتين للإنهاء):{RESET}")
    
    lines = []
    while True:
        line = input()
        if line == "":
            break
        lines.append(line)
    
    text = "\n".join(lines)
    if not text:
        print(f"{RED}لم يتم إدخال نص{RESET}")
        return
    
    print(f"\n{YELLOW}جاري التحليل...{RESET}")
    analysis = advisor.analyze(text)
    
    risk_color = {
        "منخفض": GREEN,
        "متوسط": YELLOW,
        "عالي": RED,
        "حرج": RED + BOLD
    }.get(analysis.risk_level, RESET)
    
    print(f"""
{GREEN}═══ نتيجة التحليل ═══{RESET}
  {BOLD}نوع الوكالة:{RESET}  {analysis.wakala_type}
  {BOLD}مستوى الخطر:{RESET} {risk_color}{analysis.risk_level}{RESET}
  {BOLD}التحذيرات:{RESET}   {len(analysis.warnings)}
""")
    
    if analysis.warnings:
        print(f"  {RED}{BOLD}⚠ التحذيرات:{RESET}")
        for w in analysis.warnings:
            print(f"    • [{w.level}] {w.term}")
            print(f"      {w.warning}")
            print(f"      {CYAN}→ {w.recommendation}{RESET}")
            print()
    
    if analysis.safe_alternative:
        print(f"  {GREEN}{BOLD}✓ البديل الآمن:{RESET}")
        print(f"    {analysis.safe_alternative[:200]}...")

def suggest_safe_wakala(advisor):
    """اقتراح وكالة آمنة"""
    print(f"\n{CYAN}═══ اقتراح وكالة آمنة ═══{RESET}")
    print(f"""
{BOLD}اختر الغرض:{RESET}
  1. بيع عقار
  2. استلام مستندات
  3. تجديد جواز
  4. غرض آخر
""")
    choice = input(f"{BOLD}الاختيار:{RESET} ").strip()
    
    purposes = {
        "1": "بيع عقار",
        "2": "استلام مستندات", 
        "3": "تجديد جواز"
    }
    
    if choice in purposes:
        purpose = purposes[choice]
    elif choice == "4":
        purpose = input(f"{BOLD}أدخل الغرض:{RESET} ").strip()
    else:
        print(f"{RED}اختيار غير صحيح{RESET}")
        return
    
    print(f"\n{YELLOW}جاري إنشاء الوكالة...{RESET}")
    safe = advisor.suggest_safe_wakala(purpose)
    
    print(f"\n{GREEN}═══ نموذج الوكالة الآمنة ═══{RESET}")
    print(f"\n{safe}\n")

def search_kb(rag):
    """البحث في قاعدة المعرفة"""
    print(f"\n{CYAN}═══ البحث ═══{RESET}")
    query = input(f"{BOLD}أدخل كلمات البحث:{RESET} ").strip()
    
    if not query:
        print(f"{RED}لم يتم إدخال نص{RESET}")
        return
    
    print(f"\n{YELLOW}جاري البحث...{RESET}")
    results = rag.search(query, top_k=5)
    
    print(f"\n{GREEN}═══ النتائج ({len(results)}) ═══{RESET}\n")
    
    for i, r in enumerate(results, 1):
        score_pct = r.score * 100
        print(f"  {BOLD}[{i}]{RESET} {r.source} ({score_pct:.0f}%)")
        print(f"      {r.content[:100]}...")
        print()

def ask_question(rag):
    """سؤال وجواب"""
    print(f"\n{CYAN}═══ سؤال وجواب ═══{RESET}")
    question = input(f"{BOLD}أدخل سؤالك:{RESET} ").strip()
    
    if not question:
        print(f"{RED}لم يتم إدخال سؤال{RESET}")
        return
    
    print(f"\n{YELLOW}جاري البحث عن الإجابة...{RESET}")
    answer = rag.answer(question)
    
    print(f"\n{GREEN}═══ الإجابة ═══{RESET}")
    print(f"\n{answer}\n")

def process_document(rag):
    """معالجة مستند"""
    print(f"\n{CYAN}═══ معالجة مستند ═══{RESET}")
    path = input(f"{BOLD}أدخل مسار الصورة:{RESET} ").strip()
    
    if not path:
        print(f"{RED}لم يتم إدخال مسار{RESET}")
        return
    
    path = Path(path)
    if not path.exists():
        print(f"{RED}الملف غير موجود: {path}{RESET}")
        return
    
    print(f"\n{YELLOW}جاري قراءة المستند...{RESET}")
    
    with open(path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode()
    
    result = rag.process_request(
        text="استخراج بيانات المستند",
        documents=[(img_b64, "auto")]
    )
    
    print(f"\n{GREEN}═══ البيانات المستخرجة ═══{RESET}")
    if result.documents:
        doc = result.documents[0]
        print(f"  {BOLD}النوع:{RESET} {doc.document_type}")
        print(f"  {BOLD}الدقة:{RESET} {doc.confidence*100:.0f}%")
        print(f"  {BOLD}الحقول:{RESET}")
        for k, v in doc.fields.items():
            print(f"    • {k}: {v}")
    else:
        print(f"  {RED}لم يتم استخراج بيانات{RESET}")

def show_stats(rag):
    """إحصائيات النظام"""
    print(f"\n{CYAN}═══ إحصائيات النظام ═══{RESET}")
    
    stats = rag.stats()
    
    print(f"""
  {BOLD}قاعدة المعرفة:{RESET}
    • المستندات: {stats.get('documents', 'N/A')}
    • Vector DB: {stats.get('vector_db', 'N/A')}
  
  {BOLD}النماذج:{RESET}
    • LLM: {stats.get('llm_model', 'N/A')}
    • Embeddings: {stats.get('embed_model', 'N/A')}
    • Vision: {stats.get('vision_model', 'N/A')}
  
  {BOLD}الحالة:{RESET}
    • Ollama: {'✓ متصل' if stats.get('ollama_connected') else '✗ غير متصل'}
    • Mock Mode: {'نعم' if stats.get('mock_mode') else 'لا'}
""")

def main():
    print_header()
    
    print(f"{YELLOW}جاري تهيئة النظام...{RESET}")
    
    try:
        rag = create_rag_system()
        advisor = WakalaAdvisor()
        print(f"{GREEN}✓ تم تهيئة النظام بنجاح{RESET}")
    except Exception as e:
        print(f"{RED}✗ فشل تهيئة النظام: {e}{RESET}")
        print(f"{YELLOW}جاري التشغيل في وضع Mock...{RESET}")
        rag = create_rag_system(mock=True)
        advisor = WakalaAdvisor()
    
    print_menu()
    
    while True:
        try:
            cmd = input(f"\n{BOLD}>{RESET} ").strip().lower()
            
            if cmd in ["q", "quit", "exit", "خروج"]:
                print(f"\n{CYAN}مع السلامة! 👋{RESET}\n")
                break
            elif cmd in ["h", "help", "?", "مساعدة"]:
                print_menu()
            elif cmd == "1":
                process_request(rag)
            elif cmd == "2":
                analyze_wakala(advisor)
            elif cmd == "3":
                suggest_safe_wakala(advisor)
            elif cmd == "4":
                search_kb(rag)
            elif cmd == "5":
                ask_question(rag)
            elif cmd == "6":
                process_document(rag)
            elif cmd == "7":
                show_stats(rag)
            else:
                print(f"{YELLOW}أمر غير معروف. اكتب 'h' للمساعدة{RESET}")
                
        except KeyboardInterrupt:
            print(f"\n\n{CYAN}مع السلامة! 👋{RESET}\n")
            break
        except Exception as e:
            print(f"{RED}خطأ: {e}{RESET}")

if __name__ == "__main__":
    main()
