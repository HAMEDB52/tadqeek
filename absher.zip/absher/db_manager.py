"""
Database Manager - JSON CRUD Operations
إدارة قاعدة البيانات
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, List, Any
from dataclasses import dataclass

DB_PATH = Path(__file__).parent / "database.json"


@dataclass
class DocumentStatus:
    """حالة المستند"""
    name: str
    expiry_date: str
    status: str  # valid, expired, expiring_soon
    days_remaining: int
    emoji: str


class DatabaseManager:
    """مدير قاعدة البيانات"""
    
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self.data = self._load()
    
    def _load(self) -> Dict:
        """تحميل البيانات"""
        if self.db_path.exists():
            with open(self.db_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"citizens": [], "requests": [], "wakalas": [], "metadata": {}}
    
    def _save(self):
        """حفظ البيانات"""
        self.data["metadata"]["last_updated"] = datetime.now().isoformat()
        with open(self.db_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    # ==================== Citizens ====================
    
    def get_citizen(self, id_number: str) -> Optional[Dict]:
        """البحث عن مواطن بالرقم"""
        for citizen in self.data["citizens"]:
            if citizen["id_number"] == id_number:
                return citizen
        return None
    
    def get_citizen_by_name(self, name: str) -> Optional[Dict]:
        """البحث بالاسم"""
        name_lower = name.lower()
        for citizen in self.data["citizens"]:
            if name_lower in citizen["name_ar"].lower() or name_lower in citizen["name_en"].lower():
                return citizen
        return None
    
    def get_citizen_by_phone(self, phone: str) -> Optional[Dict]:
        """البحث برقم الجوال"""
        phone_clean = phone.replace(" ", "").replace("-", "")
        for citizen in self.data["citizens"]:
            if citizen["phone"] == phone_clean:
                return citizen
        return None
    
    def update_citizen(self, id_number: str, updates: Dict) -> bool:
        """تحديث بيانات مواطن"""
        for i, citizen in enumerate(self.data["citizens"]):
            if citizen["id_number"] == id_number:
                self.data["citizens"][i].update(updates)
                self._save()
                return True
        return False
    
    def update_document(self, id_number: str, doc_type: str, updates: Dict) -> bool:
        """تحديث مستند"""
        citizen = self.get_citizen(id_number)
        if citizen and doc_type in citizen.get("documents", {}):
            citizen["documents"][doc_type].update(updates)
            self._save()
            return True
        return False
    
    # ==================== Document Status ====================
    
    def check_document_status(self, expiry_date: str) -> tuple:
        """فحص حالة المستند"""
        try:
            expiry = datetime.strptime(expiry_date, "%Y-%m-%d")
            today = datetime.now()
            days_remaining = (expiry - today).days
            
            if days_remaining < 0:
                return "expired", days_remaining, "❌"
            elif days_remaining <= 90:
                return "expiring_soon", days_remaining, "⚠️"
            else:
                return "valid", days_remaining, "✅"
        except:
            return "unknown", 0, "❓"
    
    def get_citizen_documents_status(self, id_number: str) -> List[DocumentStatus]:
        """الحصول على حالة جميع مستندات المواطن"""
        citizen = self.get_citizen(id_number)
        if not citizen:
            return []
        
        results = []
        doc_names = {
            "national_id": "الهوية الوطنية",
            "passport": "جواز السفر",
            "driving_license": "رخصة القيادة",
            "vehicle_registration": "استمارة المركبة"
        }
        
        for doc_key, doc_data in citizen.get("documents", {}).items():
            if "expiry_date" in doc_data:
                status, days, emoji = self.check_document_status(doc_data["expiry_date"])
                results.append(DocumentStatus(
                    name=doc_names.get(doc_key, doc_key),
                    expiry_date=doc_data["expiry_date"],
                    status=status,
                    days_remaining=days,
                    emoji=emoji
                ))
        
        return results
    
    def get_expired_documents(self, id_number: str) -> List[str]:
        """الحصول على المستندات المنتهية"""
        statuses = self.get_citizen_documents_status(id_number)
        return [s.name for s in statuses if s.status == "expired"]
    
    def get_expiring_soon_documents(self, id_number: str) -> List[str]:
        """الحصول على المستندات القريبة من الانتهاء"""
        statuses = self.get_citizen_documents_status(id_number)
        return [s.name for s in statuses if s.status == "expiring_soon"]
    
    # ==================== Requests ====================
    
    def create_request(self, citizen_id: str, service: str, category: str, details: Dict = None) -> str:
        """إنشاء طلب جديد"""
        request_id = f"REQ-{datetime.now().strftime('%Y%m%d%H%M%S')}-{len(self.data['requests'])+1:03d}"
        
        request = {
            "request_id": request_id,
            "citizen_id": citizen_id,
            "service": service,
            "category": category,
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "completed_at": None,
            "details": details or {}
        }
        
        self.data["requests"].append(request)
        self.data["metadata"]["total_requests"] = len(self.data["requests"])
        self._save()
        
        return request_id
    
    def complete_request(self, request_id: str, details: Dict = None) -> bool:
        """إكمال طلب"""
        for request in self.data["requests"]:
            if request["request_id"] == request_id:
                request["status"] = "completed"
                request["completed_at"] = datetime.now().isoformat()
                if details:
                    request["details"].update(details)
                self._save()
                return True
        return False
    
    def get_citizen_requests(self, citizen_id: str) -> List[Dict]:
        """الحصول على طلبات مواطن"""
        return [r for r in self.data["requests"] if r["citizen_id"] == citizen_id]
    
    def get_pending_requests(self, citizen_id: str) -> List[Dict]:
        """الطلبات المعلقة"""
        return [r for r in self.data["requests"] 
                if r["citizen_id"] == citizen_id and r["status"] == "pending"]
    
    # ==================== Renewals ====================
    
    def renew_document(self, citizen_id: str, doc_type: str, years: int = 10) -> Dict:
        """تجديد مستند"""
        citizen = self.get_citizen(citizen_id)
        if not citizen:
            return {"success": False, "error": "المواطن غير موجود"}
        
        doc_map = {
            "هوية": "national_id",
            "الهوية": "national_id",
            "الهوية الوطنية": "national_id",
            "جواز": "passport",
            "الجواز": "passport",
            "جواز السفر": "passport",
            "رخصة": "driving_license",
            "الرخصة": "driving_license",
            "رخصة القيادة": "driving_license",
            "استمارة": "vehicle_registration",
            "الاستمارة": "vehicle_registration",
            "استمارة المركبة": "vehicle_registration"
        }
        
        doc_key = doc_map.get(doc_type, doc_type)
        
        if doc_key not in citizen.get("documents", {}):
            return {"success": False, "error": f"المستند {doc_type} غير موجود"}
        
        old_expiry = citizen["documents"][doc_key].get("expiry_date")
        new_expiry = (datetime.now() + timedelta(days=years*365)).strftime("%Y-%m-%d")
        
        # Update document
        citizen["documents"][doc_key]["expiry_date"] = new_expiry
        citizen["documents"][doc_key]["issue_date"] = datetime.now().strftime("%Y-%m-%d")
        citizen["documents"][doc_key]["status"] = "valid"
        
        # Create request record
        service_names = {
            "national_id": "تجديد الهوية الوطنية",
            "passport": "تجديد جواز السفر",
            "driving_license": "تجديد رخصة القيادة",
            "vehicle_registration": "تجديد استمارة المركبة"
        }
        
        category_map = {
            "national_id": "الأحوال المدنية",
            "passport": "الجوازات",
            "driving_license": "المرور",
            "vehicle_registration": "المرور"
        }
        
        request_id = self.create_request(
            citizen_id=citizen_id,
            service=service_names.get(doc_key, f"تجديد {doc_type}"),
            category=category_map.get(doc_key, "أخرى"),
            details={
                "old_expiry": old_expiry,
                "new_expiry": new_expiry
            }
        )
        
        self.complete_request(request_id)
        self._save()
        
        return {
            "success": True,
            "request_id": request_id,
            "old_expiry": old_expiry,
            "new_expiry": new_expiry,
            "message": f"تم تجديد {service_names.get(doc_key, doc_type)} بنجاح"
        }
    
    # ==================== Wakalas ====================
    
    def create_wakala(self, grantor_id: str, grantee_id: str, wakala_type: str, 
                      purpose: str, details: str, months: int = 6) -> Dict:
        """إنشاء وكالة"""
        grantor = self.get_citizen(grantor_id)
        grantee = self.get_citizen(grantee_id)
        
        if not grantor:
            return {"success": False, "error": "الموكِّل غير موجود"}
        if not grantee:
            return {"success": False, "error": "الوكيل غير موجود"}
        
        wakala_id = f"WKL-{datetime.now().strftime('%Y%m%d')}-{len(self.data['wakalas'])+1:03d}"
        
        wakala = {
            "wakala_id": wakala_id,
            "grantor_id": grantor_id,
            "grantor_name": grantor["name_ar"],
            "grantee_id": grantee_id,
            "grantee_name": grantee["name_ar"],
            "type": wakala_type,
            "purpose": purpose,
            "details": details,
            "issue_date": datetime.now().strftime("%Y-%m-%d"),
            "expiry_date": (datetime.now() + timedelta(days=months*30)).strftime("%Y-%m-%d"),
            "status": "active"
        }
        
        self.data["wakalas"].append(wakala)
        self.data["metadata"]["total_wakalas"] = len(self.data["wakalas"])
        self._save()
        
        return {
            "success": True,
            "wakala_id": wakala_id,
            "wakala": wakala,
            "message": f"تم إنشاء الوكالة رقم {wakala_id} بنجاح"
        }
    
    def get_citizen_wakalas(self, citizen_id: str) -> Dict:
        """الحصول على وكالات المواطن"""
        as_grantor = [w for w in self.data["wakalas"] if w["grantor_id"] == citizen_id]
        as_grantee = [w for w in self.data["wakalas"] if w["grantee_id"] == citizen_id]
        return {
            "as_grantor": as_grantor,  # وكالات أعطيتها
            "as_grantee": as_grantee   # وكالات استلمتها
        }
    
    def cancel_wakala(self, wakala_id: str) -> bool:
        """إلغاء وكالة"""
        for wakala in self.data["wakalas"]:
            if wakala["wakala_id"] == wakala_id:
                wakala["status"] = "cancelled"
                self._save()
                return True
        return False
    
    # ==================== Statistics ====================
    
    def get_statistics(self) -> Dict:
        """إحصائيات عامة"""
        total_citizens = len(self.data["citizens"])
        
        expired_docs = 0
        expiring_docs = 0
        
        for citizen in self.data["citizens"]:
            for doc in citizen.get("documents", {}).values():
                if "expiry_date" in doc:
                    status, _, _ = self.check_document_status(doc["expiry_date"])
                    if status == "expired":
                        expired_docs += 1
                    elif status == "expiring_soon":
                        expiring_docs += 1
        
        return {
            "total_citizens": total_citizens,
            "total_requests": len(self.data["requests"]),
            "pending_requests": len([r for r in self.data["requests"] if r["status"] == "pending"]),
            "completed_requests": len([r for r in self.data["requests"] if r["status"] == "completed"]),
            "total_wakalas": len(self.data["wakalas"]),
            "active_wakalas": len([w for w in self.data["wakalas"] if w["status"] == "active"]),
            "expired_documents": expired_docs,
            "expiring_soon_documents": expiring_docs
        }
    
    def get_all_citizens_summary(self) -> List[Dict]:
        """ملخص جميع المواطنين"""
        summary = []
        for citizen in self.data["citizens"]:
            expired = self.get_expired_documents(citizen["id_number"])
            expiring = self.get_expiring_soon_documents(citizen["id_number"])
            summary.append({
                "id_number": citizen["id_number"],
                "name": citizen["name_ar"],
                "phone": citizen["phone"],
                "expired_docs": len(expired),
                "expiring_docs": len(expiring),
                "status": "⚠️" if expired else ("⏰" if expiring else "✅")
            })
        return summary


# Singleton instance
_db = None

def get_db() -> DatabaseManager:
    """Get database instance"""
    global _db
    if _db is None:
        _db = DatabaseManager()
    return _db


# ==================== Quick Test ====================
if __name__ == "__main__":
    db = get_db()
    
    print("=== Database Test ===\n")
    
    # Test citizen lookup
    citizen = db.get_citizen("1087654321")
    if citizen:
        print(f"✓ Found: {citizen['name_ar']}")
        
        # Check documents
        print("\n📄 Documents Status:")
        for doc in db.get_citizen_documents_status("1087654321"):
            print(f"  {doc.emoji} {doc.name}: {doc.expiry_date} ({doc.days_remaining} days)")
        
        # Expired docs
        expired = db.get_expired_documents("1087654321")
        if expired:
            print(f"\n❌ Expired: {expired}")
    
    # Statistics
    print("\n📊 Statistics:")
    stats = db.get_statistics()
    for k, v in stats.items():
        print(f"  {k}: {v}")
