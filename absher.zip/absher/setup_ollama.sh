#!/bin/bash
# setup_ollama.sh
# إعداد Ollama للـ RAG System
# RTX 5070 Ti 16GB VRAM

echo "=============================================="
echo "🔷 RAG Absher - Ollama Setup"
echo "=============================================="

# التحقق من Ollama
if ! command -v ollama &> /dev/null; then
    echo "❌ Ollama not installed!"
    echo "Install from: https://ollama.ai"
    exit 1
fi

echo "✓ Ollama found"

# تشغيل Ollama
echo ""
echo "🚀 Starting Ollama..."
ollama serve &
sleep 3

# تحميل النماذج
echo ""
echo "📥 Downloading models for RTX 5070 Ti (16GB)..."
echo ""

# LLM - الأفضل للعربية
echo "1/3 Downloading qwen2.5:14b (best for Arabic)..."
ollama pull qwen2.5:14b

# Embeddings
echo ""
echo "2/3 Downloading nomic-embed-text (embeddings)..."
ollama pull nomic-embed-text

# Vision/OCR
echo ""
echo "3/3 Downloading llama3.2-vision (OCR)..."
ollama pull llama3.2-vision

# بدائل أخف (اختياري)
echo ""
echo "📥 Downloading lightweight alternatives (optional)..."
ollama pull llama3.2
ollama pull llava:7b

echo ""
echo "=============================================="
echo "✅ Setup Complete!"
echo "=============================================="
echo ""
echo "Models installed:"
ollama list
echo ""
echo "To test:"
echo "  python tests.py"
echo ""
